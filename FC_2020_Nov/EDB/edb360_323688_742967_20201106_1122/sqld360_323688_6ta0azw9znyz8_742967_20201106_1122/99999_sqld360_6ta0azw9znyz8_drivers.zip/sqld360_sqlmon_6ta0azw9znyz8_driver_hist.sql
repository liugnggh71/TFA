BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 242153
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_6ta0azw9znyz8_16819875_11022020020814_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 242150
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_6ta0azw9znyz8_16819874_11022020020814_hist.html;
PRINT :myreport;
SPO OFF;

BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 107058
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_33554432_09252020001256_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 132307
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_33554432_09292020003214_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 98016
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_16777217_09222020000230_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 179011
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_33554432_10132020001458_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 220142
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_33554433_10272020001929_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 202131
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_16777216_10212020002010_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 176083
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_16777216_10122020001715_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 199253
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_33554432_10202020001322_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 233244
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_16777216_10302020001732_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 245418
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_33554432_11032020000857_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 207877
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_33554432_10232020001652_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 248960
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_7uxfahgurqu0d_33554432_11042020001035_hist.html;
PRINT :myreport;
SPO OFF;

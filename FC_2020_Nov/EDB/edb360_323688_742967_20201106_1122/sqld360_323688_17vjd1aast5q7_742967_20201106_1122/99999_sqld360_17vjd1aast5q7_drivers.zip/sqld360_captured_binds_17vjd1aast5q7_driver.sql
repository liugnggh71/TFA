SET PAGES 50000
SPO 00594_sqld360_323688_17vjd1aast5q7_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B1 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B1'
AND datatype_string = 'NESTED TABLE'
AND sql_id = '17vjd1aast5q7'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B1'
AND datatype_string = 'NESTED TABLE'
AND sql_id = '17vjd1aast5q7'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3485 AND 4974
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00594_sqld360_323688_17vjd1aast5q7_2g_54_captured_binds_details.html APP;
PRO </td>

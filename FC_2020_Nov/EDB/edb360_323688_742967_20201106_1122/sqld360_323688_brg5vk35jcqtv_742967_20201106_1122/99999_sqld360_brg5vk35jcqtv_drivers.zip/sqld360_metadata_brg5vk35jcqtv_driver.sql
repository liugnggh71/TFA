BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_APBL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_MEMBDGISBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'FUNCTION'
, name => 'REVERSE_STR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IXB_USR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IXB_USR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_ACTLUNTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_APRDUNTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_DENLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_RQTDUNTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBDG_MDCLCLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_AMTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_CM_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_SENTASMT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_THE_BRNCACT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMDI_CMBASE_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FK_PRBLM_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_DGISUMEVNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_HICNID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_HICNID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_HICNID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_INSCID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_INSCID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_INSCID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEDICAID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEDICAID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEDICAID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEMBPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_RLSPTO_SBCR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_SBCR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_SCL_SCTYNMBR_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_SCL_SCTYNMBR_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_MEMB_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_SRC__ASMTCARECALC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_SRC__PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_TAKNASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_BED_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_LAS_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_MDCLSRVCTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_MNLYDRMDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PLCEOF_SRVCTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PVDRASTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_SNP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_FF_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_MBUR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_PAYR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_PRV_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_USR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_ACTLWKLD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_BCK1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_BCK2'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_BCK3'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_CSTMWKLDLMIT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_EMPEID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_EMPEID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_PAYRPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_RGNLSNGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_SCL_SCTYNMBR_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_SCL_SCTYNMBR_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_STCYNOTEPRPS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_SVSR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_FED_TAX_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_FED_TAX_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PCP_CAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PLN_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PLN_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PVDRPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PVDRTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_SPLRTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_UPN_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_UPN_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_T_APBL_APBL_UMEVENT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_T_APBL_MSDG_MID_CT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMAD_UMBS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_ID_RQNGPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_LTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OWNROBST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OWNR_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OWNR_STT_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_PFNGPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_PITY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_PMRYPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RQNGPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RQTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RTNGPEER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_SRC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_SVTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMDS_DGISUMEVNT_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMDS_SNP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_DENLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_RJTNRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_CLSRRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_FRSTOPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_CLSDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_RPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_REONRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_REQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_UM_EVNTOTCM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_DCLYXTDD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_MNLYDRMDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRNTEVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_XTDD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_CNCTINFO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_ECTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_FRSTNAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_FRSTNAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_IDNODELMSTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_LAS_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MDLENAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MDLENAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MRGEMSTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MRGEMSTR_MBUR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_NAM_PRFX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_NAM_SFIX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PMRYLANG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTMEMBDGISX5'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTUMBBX1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_APBL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_MEMBDGISBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_APBL_UX_PRNTEVNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_CFPRBLMDS_THE_BRNCACT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_CLSTYP_MRGE_LAS_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_MBUR_SCL_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_OBJ_STT2_MRGMSTR_NULL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_PAYR_SSN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_PRV_PLN_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_TUNE1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_TUNE2'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_C4C_ID_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_NAM3'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_NAM4'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_SPEC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CBDG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CFDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CFPRBLMDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMDI'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_FF'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MBUR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MDSS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MSRV'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PRV'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_T_UM_BASE_UMBS_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMET'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMXT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;

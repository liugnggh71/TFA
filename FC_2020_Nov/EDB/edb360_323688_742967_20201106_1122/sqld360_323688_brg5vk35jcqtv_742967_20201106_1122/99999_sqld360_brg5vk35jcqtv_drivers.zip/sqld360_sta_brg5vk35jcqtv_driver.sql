SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_100354') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99740') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_98403') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99984') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_97689') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_98919') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_97485') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99267') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99124') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99879') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_98301') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_97727') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_98545') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_100253') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_97587') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_100152') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99638') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_98200') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_100455') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_98099') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_98440') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99021') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99435') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_97831') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99162') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_97998') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_98817') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99842') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99537') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_98712') FROM dual;
------------------------------------------------------------------------

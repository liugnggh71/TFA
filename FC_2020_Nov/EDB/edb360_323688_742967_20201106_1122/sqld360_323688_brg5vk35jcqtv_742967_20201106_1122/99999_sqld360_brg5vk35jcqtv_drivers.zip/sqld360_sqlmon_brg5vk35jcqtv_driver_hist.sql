BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 233982
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_brg5vk35jcqtv_33558515_10302020065849_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 188916
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_brg5vk35jcqtv_33591519_10162020060136_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 205397
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_brg5vk35jcqtv_33560988_10222020065056_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 156696
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_brg5vk35jcqtv_33574098_10052020072446_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 230400
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_brg5vk35jcqtv_16779193_10292020065542_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 216474
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_brg5vk35jcqtv_16786611_10262020065559_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 252590
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_brg5vk35jcqtv_16778296_11052020074257_hist.html;
PRINT :myreport;
SPO OFF;

BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_BENSPKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CM_BASEBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_DDL_ITEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_ENNS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'FUNCTION'
, name => 'GET_RANGE_HIGHBOUNDX_VALUE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'FUNCTION'
, name => 'GET_RANGE_HIGHBOUND_VALUE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'FUNCTION'
, name => 'GET_RANGE_LOWBOUND_VALUE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'FUNCTION'
, name => 'IS_ACCESS_ALLOWED_TO_MEMBER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'FUNCTION'
, name => 'IS_ENROLL_TERM_DATE_EXCLUDED'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'FUNCTION'
, name => 'REVERSE_STR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IXB_USR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IXB_USR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ATTP_DFLTLTR_HEAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ATTP_DSCM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_BEN_FIL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_LWSTLVL_PRODCAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BENP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CAREPLAN_NOTE_ID_DDLI_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_CLSRRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_FRSTOPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_LAS_CLSDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_LAS_RPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_OWNR_OBJSTT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRJ_OTCM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_REONRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_REQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTP_DFLTLDNGMSG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_ORIGCRTR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_ORIGCRTR_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_OWNROBST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_OWN_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_PITY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_PMRYPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_RESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_SRC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_SVTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBS_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBS_PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBS_QRY_STTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBS_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_DENLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_RJTNRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_RTNGPEER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_CLSRRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_FRSTOPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_LAS_CLSDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_LAS_RPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRJ_OTCM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_REONRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_REQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMTB_AMTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_DENLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_RJTNRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_RTNGPEER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_DDL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_BENPENLTDSNDTIDMEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_CNRTNMBR_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_CNRTNMBR_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_CNTRNLTDSNDTIDMEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_DTSTTIDMEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_IPGDTSTTIDMEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_MEMBENLTDTDSNTDTID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_MEMBENLTDTDSNTDTSTTID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_MEMBENPENLTDSNDT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_HICNID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_HICNID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_HICNID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_INSCID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_INSCID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_INSCID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEDICAID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEDICAID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEDICAID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEMBPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_RLSPTO_SBCR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_SBCR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_SCL_SCTYNMBR_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_SCL_SCTYNMBR_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_FF_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_MBUR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_PAYR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_PRV_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_USR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OBJ_STT_AFFN_MEMB_SETK_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_ACTLWKLD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_BCK1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_BCK2'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_BCK3'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_CSTMWKLDLMIT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_EMPEID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_EMPEID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_PAYRPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_RGNLSNGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_SCL_SCTYNMBR_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_SCL_SCTYNMBR_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_STCYNOTEPRPS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_SVSR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_FED_TAX_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_FED_TAX_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PCP_CAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PLN_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PLN_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PVDRPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PVDRTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_SPLRTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_UPN_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_UPN_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SCBT_CAREBEANTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SCBT_CB_SETK_TMTD_AFFM_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SCBT_CB_STK_TD_AFM_NVL_PRNL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CNCLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_ORIGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_OWNRORIGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_REPP_STARTDATEALL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_RETNPTRN_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_SENT_Y2D'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_SRC__ASMTCARECALC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_SRC__PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_STARTDATEALL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_STRTSNLTDT_LOWB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TAKNASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TMTD_HIGHB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TMTD_HIGHBX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TSK_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SKC4CID_SKID_SKTSKNM_CT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STNT_ID_DDLI_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TSKT_ICON'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TSKT_RCPTTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_ID_RQNGPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_LTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OWNROBST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OWNR_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OWNR_STT_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_PFNGPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_PITY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_PMRYPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RQNGPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RQTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RTNGPEER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_SRC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_SVTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_DENLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_RJTNRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_CLSRRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_FRSTOPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_CLSDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_RPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_REONRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_REQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_UM_EVNTOTCM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_CNCTINFO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_ECTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_FRSTNAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_FRSTNAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_IDNODELMSTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_LAS_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MDLENAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MDLENAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MRGEMSTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MRGEMSTR_MBUR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_NAM_PRFX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_NAM_SFIX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PMRYLANG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTCMBBX6'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTCMBBX7'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTUMBBX1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_BENSPKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CM_BASEBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_DDL_ITEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_ENNS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_DDL_ITEM_IX_DDLI_LBL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTSK_UX_EVNTREQT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_CM_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_EVNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_EXTN_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_ORIG_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_CLSTYP_MRGE_LAS_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_MBUR_SCL_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_OBJ_STT2_MRGMSTR_NULL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_PAYR_SSN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_PRV_PLN_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_TUNE1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_TUNE2'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_C4C_ID_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_NAM3'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_NAM4'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_SPEC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ATTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_BMTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_BPTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CBS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CCTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CDTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMBS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMPB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMPQ'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMPR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMTB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CNTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CPNY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CRQB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CRTB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CSRQ'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CTYB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ETTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_EUCY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_FCTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_FF'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_IMDY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LHTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LLTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LTTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MBUR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MMGY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MNTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_NCTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PIQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PLNS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PRNY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PRV'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PTTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_QTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_RPTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_SCBT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_TITY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_TSKT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_T_UM_BASE_UMBS_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UENY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMET'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'VIEW'
, name => 'V_CURR_ENROLLMENT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;

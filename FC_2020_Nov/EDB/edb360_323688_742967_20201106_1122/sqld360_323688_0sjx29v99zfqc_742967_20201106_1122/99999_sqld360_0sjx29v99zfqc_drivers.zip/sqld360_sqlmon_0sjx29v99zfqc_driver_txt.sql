BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 1950
, session_serial => 6076
, sql_exec_start => TO_DATE('20201106171502', 'YYYYMMDDHH24MISS')
, sql_exec_id => 33556489
, inst_id => 2
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_33556489_20201106171502.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 3103
, session_serial => 9263
, sql_exec_start => TO_DATE('20201106171448', 'YYYYMMDDHH24MISS')
, sql_exec_id => 33556488
, inst_id => 2
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_33556488_20201106171448.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 3103
, session_serial => 9263
, sql_exec_start => TO_DATE('20201106171414', 'YYYYMMDDHH24MISS')
, sql_exec_id => 33556487
, inst_id => 2
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_33556487_20201106171414.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 1950
, session_serial => 6076
, sql_exec_start => TO_DATE('20201106171413', 'YYYYMMDDHH24MISS')
, sql_exec_id => 33556486
, inst_id => 2
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_33556486_20201106171413.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 1950
, session_serial => 6076
, sql_exec_start => TO_DATE('20201106171200', 'YYYYMMDDHH24MISS')
, sql_exec_id => 33556485
, inst_id => 2
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_33556485_20201106171200.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 5824
, session_serial => 60482
, sql_exec_start => TO_DATE('20201106165849', 'YYYYMMDDHH24MISS')
, sql_exec_id => 16778660
, inst_id => 1
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_16778660_20201106165849.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 3480
, session_serial => 1010
, sql_exec_start => TO_DATE('20201106165503', 'YYYYMMDDHH24MISS')
, sql_exec_id => 16778659
, inst_id => 1
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_16778659_20201106165503.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 1950
, session_serial => 42178
, sql_exec_start => TO_DATE('20201106165220', 'YYYYMMDDHH24MISS')
, sql_exec_id => 33556484
, inst_id => 2
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_33556484_20201106165220.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 1950
, session_serial => 42178
, sql_exec_start => TO_DATE('20201106164558', 'YYYYMMDDHH24MISS')
, sql_exec_id => 33556483
, inst_id => 2
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_33556483_20201106164558.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 1950
, session_serial => 42178
, sql_exec_start => TO_DATE('20201106162624', 'YYYYMMDDHH24MISS')
, sql_exec_id => 33556481
, inst_id => 2
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_33556481_20201106162624.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 1950
, session_serial => 42178
, sql_exec_start => TO_DATE('20201106162531', 'YYYYMMDDHH24MISS')
, sql_exec_id => 33556480
, inst_id => 2
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_33556480_20201106162531.txt;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '0sjx29v99zfqc'
, session_id => 5822
, session_serial => 14768
, sql_exec_start => TO_DATE('20201106162208', 'YYYYMMDDHH24MISS')
, sql_exec_id => 16778649
, inst_id => 1
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_0sjx29v99zfqc_16778649_20201106162208.txt;
PRINT :myreport;
SPO OFF;

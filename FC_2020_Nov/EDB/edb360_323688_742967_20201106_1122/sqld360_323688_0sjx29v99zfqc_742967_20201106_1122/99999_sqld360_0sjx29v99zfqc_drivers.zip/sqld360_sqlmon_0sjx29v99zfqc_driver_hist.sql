BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 246210
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_33555870_11032020071310_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 233971
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_33555714_10302020064637_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 137474
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_33555431_09292020202331_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 178965
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_33554574_10132020001042_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 98657
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_33554543_09222020072454_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 202761
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_33554674_10212020065403_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 242847
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_33555787_11022020072233_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 179619
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_16779204_10132020070455_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 162798
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_33556311_10072020074557_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 222049
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_16777889_10272020080442_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 238524
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_33555786_10312020181513_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 246248
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_0sjx29v99zfqc_16778452_11032020074354_hist.html;
PRINT :myreport;
SPO OFF;

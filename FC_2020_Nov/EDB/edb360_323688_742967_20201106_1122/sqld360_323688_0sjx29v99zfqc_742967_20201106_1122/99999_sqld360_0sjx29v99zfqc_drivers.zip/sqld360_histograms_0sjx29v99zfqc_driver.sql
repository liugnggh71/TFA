SET PAGES 50000
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_BENSPKG.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 71257 * 71257) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 71257,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 71257 * 71257)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 71257 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BENSPKG''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_BENSPKG.BENP_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 71257 * 71257) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 71257,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 71257 * 71257)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 71257 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BENSPKG''
AND a.column_name = ''BENP_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_BENSPKG.BENP_UNIVID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 67687) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 67687)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BENSPKG''
AND a.column_name = ''BENP_UNIVID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_BENSPKG.BENP_NAM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 71257) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 71257)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BENSPKG''
AND a.column_name = ''BENP_NAM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_BENSPKG.BENP_DSCN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 71257) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 71257)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BENSPKG''
AND a.column_name = ''BENP_DSCN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_BENSPKG.(UPPER("BENP_NAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 71257) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 71257)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BENSPKG''
AND a.column_name = ''SYS_NC00027$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 * 425035) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 * 425035)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_CM_BASEBASE.CMBB_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 425035) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 425035)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 * 425035) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 * 425035)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_CM_BASEBASE.CMBB_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 425035) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 425035)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 * 425035) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 * 425035)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 * 425035) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 * 425035)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 * 425035) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 * 425035)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 425035 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CSRQ_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44416 * 44416) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44416,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44416 * 44416)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44416 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CSRQ_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CASE_CLSRRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232376 * 232376) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232376,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232376 * 232376)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232376 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CASE_CLSRRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CASE_PRJ_OTCM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33273 * 33273) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33273,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33273 * 33273)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33273 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CASE_PRJ_OTCM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CASE_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 130145 * 130145) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 130145,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 130145 * 130145)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 130145 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CASE_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CASE_PRVSOWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 80761 * 80761) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 80761,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 80761 * 80761)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 80761 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CASE_PRVSOWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CASE_REONRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 520 * 520) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 520,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 520 * 520)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 520 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CASE_REONRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMPQ_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 * 18) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 * 18)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMPQ_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMPR_CLSRRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 838 * 838) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 838,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 838 * 838)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 838 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMPR_CLSRRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMPR_PRJ_OTCM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380 * 380) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380 * 380)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMPR_PRJ_OTCM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMPR_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250452 * 250452) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250452,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250452 * 250452)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250452 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMPR_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 169598 * 169598) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 169598,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 169598 * 169598)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 169598 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 414074 * 414074) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 414074,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 414074 * 414074)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 414074 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_RESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 412742 * 412742) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 412742,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 412742 * 412742)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 412742 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_RESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_PITY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 353002 * 353002) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 353002,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 353002 * 353002)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 353002 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_PITY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_SVTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 377918 * 377918) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 377918,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 377918 * 377918)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 377918 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_SVTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_CM_BASEBASE.CMBS_MEMB'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 425035) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 425035)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBS_MEMB''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.PARTICIPATION'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 41351 * 41351) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 41351,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 41351 * 41351)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 41351 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''PARTICIPATION''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.REQUESTOR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44160 * 44160) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44160,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44160 * 44160)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44160 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''REQUESTOR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.STAGE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 47916 * 47916) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 47916,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 47916 * 47916)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 47916 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''STAGE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.TGT_INTERVENTION'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44298 * 44298) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44298,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44298 * 44298)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44298 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''TGT_INTERVENTION''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.PARTICIPATIONSTATUS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43590 * 43590) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43590,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43590 * 43590)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43590 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''PARTICIPATIONSTATUS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_CM_BASEBASE.(UPPER("CMBB_C4C_ID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 425035) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 425035)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''SYS_NC00176$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_DDL_ITEM.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10192) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10192)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10229) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10229)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEM.DDLI_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEM.DDLI_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_UNIVID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_UNIVID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_LBL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_LBL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_VAL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_VAL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEM.DDLI_SYTM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10172 * 10172) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10172,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10172 * 10172)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10172 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_SYTM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_DDL_ITEMCONSID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 3398) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 3398)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_DDL_ITEMCONSID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEM.TSKT_RCPTTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 217 * 217) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 217,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 217 * 217)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 217 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''TSKT_RCPTTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_PRNT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 2301) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 2301)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_PRNT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_DDL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_DDL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEM.("CLASSTYPE","DDLI_OBJ_STT")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''SYS_STS7_DOW3Y4SQ96_QSG9DVBTHW''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_ENNS.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14686026 * 14686026) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14686026,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14686026 * 14686026)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14686026 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686026) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686026)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ENNS.ELNS_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14686026 * 14686026) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14686026,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14686026 * 14686026)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14686026 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_UNIVID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686026) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686026)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_UNIVID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_ENLTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686025) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686025)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_ENLTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_EFTVDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686025) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686025)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_EFTVDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_DSNTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 12939444) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 12939444)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_DSNTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_TERMDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 12977424) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 12977424)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_TERMDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_BENSPKG'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14634256) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14634256)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_BENSPKG''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_INSCPRSRGRP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686025) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686025)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_INSCPRSRGRP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_PVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7208368) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7208368)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_PVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.(TRUNC("ELNS_ENLTDT"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686025) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686025)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''SYS_NC00030$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.(TRUNC(NVL("ELNS_DSNTDT",TO_DATE(' 9999-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686026) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14686026)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''SYS_NC00031$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ENNS.(DECODE("ELNS_OBJ_STT",2,NULL,'1'))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2380606 * 2380606) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2380606,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2380606 * 2380606)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2380606 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''SYS_NC00032$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_SENTTSK.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7285 * 224260) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7285,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7285 * 224260)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7285 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7287 * 224260) rows_per_bucket,
trunc(endpoint_repeat_count / 7287,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7287 * 224260)||'' Sel: ''||trunc(endpoint_repeat_count / 7287,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7287 * 224260) rows_per_bucket,
trunc(endpoint_repeat_count / 7287,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7287 * 224260)||'' Sel: ''||trunc(endpoint_repeat_count / 7287,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_VERS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_VERS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_DRTN_UNIT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876 * 2876) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876 * 2876)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_DRTN_UNIT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_RMDRPRCDWTH__UNIT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39 * 39) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39 * 39)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_RMDRPRCDWTH__UNIT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_CMPD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5915 * 180929) rows_per_bucket,
trunc(endpoint_repeat_count / 5915,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5915 * 180929)||'' Sel: ''||trunc(endpoint_repeat_count / 5915,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_CMPD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_TSK_TIMG_DDLN_DT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 2364 * 2364) rows_per_bucket,
trunc(endpoint_repeat_count / 2364,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 2364 * 2364)||'' Sel: ''||trunc(endpoint_repeat_count / 2364,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TIMG_DDLN_DT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_TSK_TIMG_DDLNACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49159 * 49159) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49159,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49159 * 49159)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49159 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TIMG_DDLNACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_TSK_TIMG_STRTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5399 * 54587) rows_per_bucket,
trunc(endpoint_repeat_count / 5399,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5399 * 54587)||'' Sel: ''||trunc(endpoint_repeat_count / 5399,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TIMG_STRTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_AFFN_UM_EVNT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21 * 21) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21 * 21)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_AFFN_UM_EVNT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_ORIGRCPT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7286 * 224260) rows_per_bucket,
trunc(endpoint_repeat_count / 7286,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7286 * 224260)||'' Sel: ''||trunc(endpoint_repeat_count / 7286,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_ORIGRCPT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219979 * 219979) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219979,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219979 * 219979)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219979 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_PRVSOWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64678 * 64678) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64678,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64678 * 64678)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64678 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_PRVSOWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_PRVSSNDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64678 * 64678) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64678,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64678 * 64678)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64678 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_PRVSSNDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_CNCLRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35441 * 35441) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35441,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35441 * 35441)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35441 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_CNCLRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_TSK_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_RESCHEDULE_REASON'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9495 * 9495) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9495,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9495 * 9495)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9495 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_RESCHEDULE_REASON''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.("SETK_OBJ_STT","SETK_AFFN_MEMB")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7285 * 224260) rows_per_bucket,
trunc(endpoint_repeat_count / 7285,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7285 * 224260)||'' Sel: ''||trunc(endpoint_repeat_count / 7285,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_STSU99E0JHXWDB$#3#GYFFGPVG''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.(NVL("SETK_PRNL",0))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 * 224260)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 224260 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_NC00086$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.(NVL("SETK_OWNR","SETK_ORIGRCPT"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7286 * 224260) rows_per_bucket,
trunc(endpoint_repeat_count / 7286,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7286 * 224260)||'' Sel: ''||trunc(endpoint_repeat_count / 7286,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_NC00087$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.(TRUNC("SETK_SENT"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7151 * 219979) rows_per_bucket,
trunc(endpoint_repeat_count / 7151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7151 * 219979)||'' Sel: ''||trunc(endpoint_repeat_count / 7151,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_NC00088$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_UM_BASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_UM_BASE.UMBS_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_DDLNTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83746 * 83746) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83746,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83746 * 83746)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83746 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_DDLNTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_REQTTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_REQTTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_DRVDDTMNSTT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250689 * 250689) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250689,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250689 * 250689)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250689 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_DRVDDTMNSTT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMET_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250602 * 250602) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250602,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250602 * 250602)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250602 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMET_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMER_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 84 * 84) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 84,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 84 * 84)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 84 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMER_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMET_UM_EVNTOTCM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10226 * 10226) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10226,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10226 * 10226)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10226 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMET_UM_EVNTOTCM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMET_CLSRRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249838 * 249838) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249838,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249838 * 249838)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249838 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMET_CLSRRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_SVTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 27 * 27) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 27,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 27 * 27)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 27 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_SVTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_PITY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 524 * 524) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 524,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 524 * 524)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 524 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_PITY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83480 * 83480) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83480,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83480 * 83480)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83480 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMET_REONRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9112 * 9112) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9112,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9112 * 9112)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9112 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMET_REONRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249340 * 249340) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249340,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249340 * 249340)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249340 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_RQTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 69961 * 69961) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 69961,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 69961 * 69961)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 69961 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_RQTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_UM_BASE.UMBS_PFNGPVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250663) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250663)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_PFNGPVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_UM_BASE.UMBS_RQNGPVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 53487) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 53487)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_RQNGPVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_AUTH_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_AUTH_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_AUTH_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_AUTH_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_UM_BASE.(UPPER("UMBS_C4C_ID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''SYS_NC00123$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_USR.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986002 * 1986002) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986002,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986002 * 1986002)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986002 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_C4C_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983161) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983161)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_C4C_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 * 1986147) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 * 1986147)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1986147) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1986147)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 * 1986147) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 * 1986147)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 * 1986147) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 * 1986147)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_UNIVID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1981511) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1981511)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_UNIVID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_FRSTNAM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1875787) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1875787)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_FRSTNAM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_LAS_NAM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983678) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983678)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_LAS_NAM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_DT_OF_BRTH'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1077282) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1077282)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_DT_OF_BRTH''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_GNDRCODE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1097041 * 1097041) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1097041,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1097041 * 1097041)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1097041 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_GNDRCODE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1986147) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1986147)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PRV_IS_ADM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985667 * 1985667) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985667,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985667 * 1985667)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985667 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PRV_IS_ADM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.MBUR_ELBL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 985202 * 985202) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 985202,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 985202 * 985202)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 985202 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''MBUR_ELBL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.MBUR_PMRYINSR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 985215 * 985215) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 985215,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 985215 * 985215)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 985215 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''MBUR_PMRYINSR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.MBUR_INSCID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 985194) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 985194)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''MBUR_INSCID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.MBUR_CNFTCNCT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 980211 * 980211) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 980211,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 980211 * 980211)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 980211 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''MBUR_CNFTCNCT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PAYR_WKLDLMITBY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 782 * 782) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 782,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 782 * 782)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 782 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_WKLDLMITBY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.PAYR_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 785) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 785)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PRV_PVDRTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209963 * 209963) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209963,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209963 * 209963)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209963 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PRV_PVDRTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_ECTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 654489 * 654489) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 654489,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 654489 * 654489)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 654489 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_ECTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_NAM_SFIX'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 87833 * 87833) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 87833,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 87833 * 87833)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 87833 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_NAM_SFIX''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_NAM_PRFX'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 629770 * 629770) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 629770,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 629770 * 629770)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 629770 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_NAM_PRFX''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.MBUR_RLSPTO_SBCR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 983812 * 983812) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 983812,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 983812 * 983812)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 983812 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''MBUR_RLSPTO_SBCR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_MRGEMSTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 419) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 419)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_MRGEMSTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PAYR_BCK1'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155 * 155) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155 * 155)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_BCK1''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PAYR_SVSR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380 * 380) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380 * 380)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_SVSR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PAYR_BCK2'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 * 15) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 * 15)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_BCK2''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PAYR_BCK3'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4 * 4) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4 * 4)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_BCK3''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PRV_SPLRTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209942 * 209942) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209942,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209942 * 209942)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209942 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PRV_SPLRTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_IPGROUPID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 193841) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 193841)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_IPGROUPID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_PRODUCTCATEGORYID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 193576) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 193576)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_PRODUCTCATEGORYID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("PRV_PLN_ID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 209961) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 209961)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00130$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("PRV_UPN_ID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 177258) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 177258)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00131$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("USR_LAS_NAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983678) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983678)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00132$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("USR_MDLENAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 790191) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 790191)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00138$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("USR_C4C_ID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983161) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983161)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00139$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.(CASE "USR_OBJ_STT" WHEN 2 THEN 0 ELSE CASE  WHEN "USR_MRGEMSTR" IS NULL THEN 1 ELSE 0 END  END )'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 * 1986147) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 * 1986147)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1986147 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00140$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.(UPPER("MBUR_MEDICAID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11 * 11) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11 * 11)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00159$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("MBUR_HICNID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 391) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 391)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00161$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("MBUR_INSCID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 985194) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 985194)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00148$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.(UPPER("PAYR_EMPEID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34 * 34) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34 * 34)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00150$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("USR_FRSTNAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1875787) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1875787)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00151$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("THH_C4C"."REVERSE_STR"("MBUR_INSCID")))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 985194) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 985194)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00155$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 01410_sqld360_323688_0sjx29v99zfqc_3a_67_histograms.html APP;
PRO </td>

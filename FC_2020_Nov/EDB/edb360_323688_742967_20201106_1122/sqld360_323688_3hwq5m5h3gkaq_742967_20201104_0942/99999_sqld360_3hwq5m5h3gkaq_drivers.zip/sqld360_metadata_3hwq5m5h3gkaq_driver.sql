BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'CLAIM_REVIEW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'CLINICALDATA_ASSN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'CLINICALDATA_AUTH_ASSN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'IHCIS_RISK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'INSTRUCTION_CARD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'MLOG$_T_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'TELEPHONE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_ALRT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_APBL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_APL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_APVLHEAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_APVLREC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_APVLTRKGDEND'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_ASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_BARRIER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_BARRIER_TEMPLATE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_BLR_PLT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CAREBEANBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CAREBEANRCTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CAREPLAN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CFRDREVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CFTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CM_BASEBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CM_CSFNPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CM_NTCERCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CNCT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CNRTSRVCFEES'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CNRTSRVCFEE_HNTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_COORDINATION_OF_BENEFITS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_CSTMWKLDLMIT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_DAT_ACC_RTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_DAYSOFF_AWNC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_DDL_ITEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_DDL_ITEMPVDRSLTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_DDL_ITEMPVDRSSPS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_DGRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_DRUGCLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_EDNLCNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_ENNS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_FAX_CSFNCASEPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_FAX_CSFNMEMBPCP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_FAX_CSFNPFNGPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_FAX_CSFNRQNGPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_FIL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_FRDSAND_FMLYLIST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_FRTSFDRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_GOALCP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_GOALCP_TEMPLATE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_GRIEVANCE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_GRP_MEMS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_ICMGFAX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_LCNSLIST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_LNGSLIST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_LTR_HEAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_LTR_RCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_LTR_SUBJ'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_LTR_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_LWSTCOSTPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_MDCLCLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_MDCLREC_CSFNMEMS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_MDCT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_MEMBCTCS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_MEMBDGISBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_MEMBPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_MEMBPCP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_NOTE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_NTCE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_ORG_CHRTITEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_ORG_CHRTITEMPRSS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_OTHER_INSURANCE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_OUTCOME'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PAYRDGISSCTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PAYRPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PAYRROLS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PAYRSRVCSCTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PHI'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PRACTITIONER_ROLE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PRMR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PRODCAT_CNTDPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PRODCAT_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PROVIDER_CHOICE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PRPDLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PRSC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PVDRADVEGRP_PVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PVDRAFFDHPTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PVDRAFFDPHYS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PVDRASTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PVDRPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PVDRPLNSAFFS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PVDR_DIR_DETAILS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_PVRSRQRGAUTH'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_QCK_SEA_SNGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_REP_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_REVWHEAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_REVWRCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_REVWREC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_REVWTRKGACTL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_RGNLSNGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_RSLSCNFG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_RTNGFLBKUSRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SENTCAREBEAN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SENTEDNLCNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SENTEMAL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SENTEMALRCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SENTLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SNRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SRVCDVONCNTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_STCYNOTESNGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SVGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SVGSALT_COST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SVGSCAT_DTLS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SYTMSTNGDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_TAKNASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_TIM_OFF_ITVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_TIM_OFF_REQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_TNFRREC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_TODO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_TODO_TEMPLATE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_TSK_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_UM_CSFNRQNGPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_UM_CSFNSENGPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_UM_EXTNNTCERCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_UM_NTCERCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_USR_BIOS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_USR_CNCTINFO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_USR_DEVICE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_USR_GRANT_DGIS_XREF'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_USR_GRANT_RESTRICTED_XREF'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_USR_LOGN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_WKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_WKFWTSK_STT_CNGE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_XMPTPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'FUNCTION'
, name => 'REVERSE_STR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_BARRIER_MEMBER_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_BARRIER_OUTCOME'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_BARRIER_SOURCE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_BARRIER_STATUS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_BARRIER_TEMPLATE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_CAREPLAN_CMBB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_CAREPLAN_STATUS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_DCLM_CLM_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_GOALCP_OUTCOME'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_GOALCP_STATUS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_GOALCP_TEMPLATE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_GOALCP_TEMPLATE_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_GOALCP_TYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_OUTCOME_REASON'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_OUTCOME_RESULT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_PRSC_CLM_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_TODO_OUTCOME'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_TODO_SETK_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_TODO_STATUS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_TODO_TEMPLATE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_TODO_TEMPLATE_PRIORITY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_TODO_TEMPLATE_TYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IDX_TODO_TYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IXB_USR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IXB_USR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_ALRTFRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_CAREBEANFRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_DGESFRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_DVTNDT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_ORIGBLR_PLT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_REP_FRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_STTSFRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_TOTLSCOR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_TSK_FRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ACCB_VSBT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ADRN_CITYOR_TOWN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ADRN_CNRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ADRN_CNTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ADRN_STT_OR_RGN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_AHNS_UNITTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_CFRDMSG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_OTCM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_RCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_RFRDOBJ_ID_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_SENTBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_SRC__ASMTCARECALC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_SRC__PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ALRT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_ACTLUNTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_APRDUNTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_DENLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_RQTDUNTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APBL_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APHD_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APHD_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APHD_FRTROPNNFOR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APHD_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APHD_OGTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APHD_RET_TO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APHD_RFRDOBJ_ID_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APHD_SNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APHD_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_APLD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_APL_RESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_APL_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APPL_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_HEAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_RFRDOBJ_ID_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_RJTNRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APRC_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APTD_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APTD_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APTD_DNNGRCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APTD_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APTD_TRKGFOR_DEND'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_APTD_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ASMT_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ATTP_DFLTLTR_HEAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ATTP_DSCM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BXES_UNITTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BXSV_ACTLUNITTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BXSV_REPLSRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BXSV_REPLSRVCPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_BXSV_XPTDUNITTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CADR_ACCPROF_ENBD_LV_DATDMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CAREPLAN_NOTE_ID_DDLI_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_CLSRRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_FRSTOPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_LAS_CLSDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_LAS_RPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_OWNR_OBJSTT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRJ_OTCM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_REONRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_REQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CASE_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBBS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBDG_MDCLCLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBRC_CAREBEAN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBRC_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBRC_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBRC_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBRC_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBRC_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBTE_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCBN_AMTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCBN_CAREBEANFRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCBN_ORIG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCBN_SENTASMT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCBN_THE_BRNCACT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCLC_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCPR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCPR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCPR_CSFN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCPR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCPR_PVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCPR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTP_DFLTLDNGMSG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDRN_SRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_CRTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CDSS_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_AMTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_CM_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_SENTASMT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_THE_BRNCACT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFGR_AMTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFGR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFGR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFGR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFGR_RCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFGR_RESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFGR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CLM_RVW_FK_PRV_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_ORIGCRTR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_ORIGCRTR_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_OWNROBST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_OWN_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_PITY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_PMRYPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_RESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_SRC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_SVTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBS_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBS_PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBS_QRY_STTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMBS_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMDI_CMBASE_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMNR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMNR_CM_REC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMNR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMNR_NTCERCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMNR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMNR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_DENLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_RJTNRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_RTNGPEER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPQ_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_CLSRRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_FRSTOPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_LAS_CLSDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_LAS_RPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRJ_OTCM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_REONRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_REQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMPR_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMTB_AMTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_COAT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_COAT_CNCTTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_COAT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_COAT_DTLS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_COAT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_COAT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CPAS_CM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CRTS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CRTS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CRTS_DSCN_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CRTS_DSCN_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CRTS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CRTS_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CRTS_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CRTS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSFE_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSFE_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSFE_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSFE_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSFE_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSFH_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSFH_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSFH_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSFH_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSFH_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_REF1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_REF2'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_REF3'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_REF4'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF10'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF11'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF12'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF13'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF14'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF15'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF16'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF17'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF18'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF19'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF20'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF21'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF22'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF23'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF24'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF25'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF26'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF27'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF28'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF29'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF30'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF31'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF32'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF33'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF34'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF35'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF36'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF37'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF38'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF39'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF40'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF5'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF6'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF7'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF8'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_RF9'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSMF_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_DENLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_RJTNRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_RTNGPEER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CSRQ_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CTSK_AMTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CTSK_ORIG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CTSK_RETNPTRN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CTSK_THE_BRNCACT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CTSK_TSK_FRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CWLM_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CWLM_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CWLM_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CWLM_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CYSD_CNRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_ACCPROF_ENBD_DATDMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_DAT_DMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_PROF_DMN_ALLADDR_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_PROF_DMN_BLRN_VAL_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_PROF_DMN_DDLITEM_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_PROF_DMN_DGIS_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_PROF_DMN_INSGRP_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_PROF_DMN_LONGVAL_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_PROF_DMN_PRODCAT_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_PROF_DMN_PVDR_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_PROF_DMN_RFROMTO_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DACR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_FRSTDT_CLMTYP_PAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_NDC_CODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_PAT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_RFNGPVDRPAT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_SENGPVDRPAT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_UMBS_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DCLM_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_DDL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDLI_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDPS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDPS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDPS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDPS_PVDRSSPS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDPS_SUB_SLTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DDPS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DEGS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DEGS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DEGS_DGRE_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DEGS_DGRE_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DEGS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DEGS_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DEGS_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DEGS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DIRN_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DLIR_DDL_ITEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DLIS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DLIS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DLIS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DLIS_PVDRSLTS_SLTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DLIS_SLTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DLIS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DLSD_DDL_ITEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DNSV_UNITTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DOAL_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DOAL_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DOAL_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DOAL_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DOAL_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DSS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DSS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DSS_TMDS_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_DSS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_CNV_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_HAS_ANMS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_HAS_ANMS_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_HAS_ANMS_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_HAS_IMGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_HAS_IMGS_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_HAS_IMGS_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_KWDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_KWDS_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_KWDS_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_PUBNDT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_SRC_DIR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_SRC_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_SRC_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_UPLDTCKT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ECNT_VSBT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_BENPENLTDSNDTIDMEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_CNRTNMBR_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_CNRTNMBR_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_CNTRNLTDSNDTIDMEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_DTSTTIDMEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_IPGDTSTTIDMEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_MEMBENLTDTDSNTDTID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_MEMBENLTDTDSNTDTSTTID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_MEMBENPENLTDSNDT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ELNS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_BACKCNTT_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ENVL_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_EXPS_ATHDDVNS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_EXPS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_EXPS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_EXPS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_EXPS_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_EXPS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_EXPS_XMPTPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FAXC_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCCP_CASEPVDRFAX_CSFN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCCP_CASEPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCCP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCCP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCCP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCCP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCMP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCMP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCMP_MEMBPCPS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCMP_MEMBPCPSFAX_CSFN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCMP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCMP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCPP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCPP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCPP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCPP_PFNGPVDRFAX_CSFN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCPP_PFNGPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCPP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCRP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCRP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCRP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCRP_RQNGPVDRFAX_CSFN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCRP_RQNGPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FCRP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FFL_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FFL_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FFL_F_NF_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FFL_MEMS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FFL_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FFL_RLSPTO_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FFL_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_CFRDLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_CM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_FIL_MEMBDGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_LTR_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_MDCLSRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_PRPDLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_TSKS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_TSK_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FILE_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FK_INS_MEMBER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FK_MDCT_REVIEWED_BY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FK_PHI_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FK_PRCE_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FK_PRCE_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FVFD_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FVFD_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FVFD_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FVFD_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FVFD_PRNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FVFD_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_GPMB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_GPMB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_GPMB_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_GPMB_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_GPMB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_GPMB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_GRVC_CLINICALDATAENTRY_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IC9DXCODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IC9D_ICD9DGESCODE_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IC9D_ICD9DGESCODE_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IC9D_SHRTDSCN_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IC9D_SHRTDSCN_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_ACPDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_CASEPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_CASERESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_CASESRC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_COMMENT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_COMMENT_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_COMMENT_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_MEMBBENSPKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_MEMBCITYOR_TOWN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_MEMBCNRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_MEMBCNTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_MEMBDGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_MEMBINSCPRSRGRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_MEMBPCP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_MEMBPMRYLANG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_MEMBSTT_OR_RGN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_REASON'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_UM_EVNTSRC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_UM_PFNGPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_UM_RQNGPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_UM_SRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IFAX_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IHRS_CDATE_PRED_MEM_RISK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IHRS_MEMBER_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ILSD_UNITOF_MSMT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_IPGR_INSCPRSRGRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LBL_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LCPV_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LCPV_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LCPV_LWSTCOSTPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LCPV_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LCPV_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LCPV_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LHFL_CNTT_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LICL_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LICL_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LICL_LIC_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LICL_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LICL_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LICL_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LICL_STT_OF_INCE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LICL_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LLT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LLT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LLT_LANGCODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LLT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LLT_PRCYCODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LLT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LLT_USR_LNGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_CC_LTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_CFRDLTR_CC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_CFRDLTR_TO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_LTR_CC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_LTR_TO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_SENTLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LRCP_USR_RCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LSGD_LANG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_PRUS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_PRUS_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_PRUS_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTHD_VSBT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_ASTNTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_CNTT_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_ENLP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_FAX_COVR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_LBL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTLT_VSBT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSD_LTR_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_AFFN_APL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_AFFN_MDCLSRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_AFFN_UM_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_PRPDLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_LTSJ_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_DGISUMEVNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_HICNID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_HICNID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_HICNID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_INSCID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_INSCID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_INSCID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEDICAID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEDICAID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEDICAID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_MEMBPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_RLSPTO_SBCR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_SBCR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_SCL_SCTYNMBR_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBUR_SCL_SCTYNMBR_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_CLM_TYP_MCLM_MDC_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_CPT4CODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_FRSTDT_MDC_CLMTYP_PAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_ICD9DX1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_ICD9DX2'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_ICD9DX3'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_MDC_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_PAT_ICD9_FRSTDT_LASDT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_PAT_ID_MCLM_CLM_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_PLCEOF_SRVCCODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_PMRYIC_D9_POC_CODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_RFNGPVDRPAT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_RVNECODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_SCDYIC_D9_POC_CODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_SENGPVDRPAT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_SPV_CPT_FDTOS_AMNTC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_UMBS_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MCLM_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_AFFDREC__CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_AFFDREC__MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_AFFDREC__PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_AFFDREC__UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_AFFDREC__UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_AFFDREC__UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_DOSGUNIT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_DRUGCLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_FLLDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_NDC_CODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_PRTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_SRC__ASMTCARECALC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_SRC__PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDCT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_MEMB_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_SRC__ASMTCARECALC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_SRC__PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_TAKNASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MMCT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MMCT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MMCT_CTCS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MMCT_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MMCT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MMCT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPAS_DRUGCLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPAS_MDCLCLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPAS_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPCP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPCP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPCP_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPCP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPCP_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPCP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPDT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPDT_CNCTINFOPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPDT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPDT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPDT_PCP_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPDT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MPDT_UP_INSCID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MRCM_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MRCM_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MRCM_CSFN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MRCM_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MRCM_SPCDMEMS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MRCM_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MRSV_UNITTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MRWH_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MRWH_PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MRWH_QRY_STTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_BED_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_LAS_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_MDCLSRVCTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_MNLYDRMDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PLCEOF_SRVCTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_PVDRASTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_SNP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MSRV_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_ATCDPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_BASENOTE_NID_CT_NCRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_CALLDRTNUNTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_CASENOTETYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_CLINICALDATAENTRY_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_CM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_CM_NOTETYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_MDCLSRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_MDCLSRVC_NID_CT_NCRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_MEMBNOTETYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_MRKDGRVCBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_MRKDRSLDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_NOTEDGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_NOTEDGIS_NID_CT_NCRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_PITY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_PVDRNOTETYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_RLTDPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_SETK_NID_CT_NCRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_UM_BASENOTE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_UM_NOTETYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NOTE_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_CFRDMSG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_FRSTSENTTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_LAS_SENTTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_RFRDOBJ_ID_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_SENTBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NTC_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_FF_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_MBUR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_PAYR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_PRV_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_NVL_USR_MRGEMSTR_USR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OBJ_STT_AFFN_MEMB_SETK_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_CNCTPRSN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_LVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_PRNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCHI_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCRP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCRP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCRP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCRP_PRSNCHRTITEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCRP_PRSN_PRSNCHRTITEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OCRP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAGS_ADVEGRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAGS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAGS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAGS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAGS_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAGS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAHO_AFFDHPTL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAHO_AFFDHPTLPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAHO_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAHO_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAHO_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAHO_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAPY_AFFDPHYN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAPY_AFFDPHYNPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAPY_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAPY_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAPY_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAPY_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_ACTLWKLD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_BCK1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_BCK2'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_BCK3'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_CSTMWKLDLMIT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_EMPEID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_EMPEID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_PAYRPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_RGNLSNGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_SCL_SCTYNMBR_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_SCL_SCTYNMBR_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_STCYNOTEPRPS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PAYR_SVSR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCCP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCCP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCCP_IN_CNRTPRODCATS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCCP_IN_CNRTPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCCP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCCP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCNS_UNITTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCPR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCPR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCPR_IN_NTWKPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCPR_IN_NTWKPVRS_PRODCAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCPR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCPR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PCRT_PRODCAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PDIS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PDIS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PDIS_DGISSCTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PDIS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PDIS_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PDIS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PERF_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PERF_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PERF_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PERF_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PERF_STTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PERF_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_AMTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_RSLSCNFG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_SCH'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PIDQ_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PPAF_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PPAF_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PPAF_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PPAF_PLNSAFFS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PPAF_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PPAF_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRAS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRAS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRAS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRAS_PVDR_CPAS_CM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRAS_PVDR_MPAS_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRAS_PVDR_UPAS_PVDRUM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRAS_ROLE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRAS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_ASMT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_CFRDLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_CNTT_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_ENLP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_FAX_COVR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_LAS_GKPR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_LBL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_LTR_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_QUE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRLT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRMR_PERF_STT_PERF_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRPD_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRPD_CNCTINFOPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRPD_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRPD_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRPD_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRPD_UP_INSCID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRRA_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRRA_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRRA_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRRA_PNDGDVONATHS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRRA_PVRSRQRGAUTH'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRRA_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRRN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRSC_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRSC_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRSC_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRSC_NDC_CODE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRSC_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRSC_RFNGPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRSC_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_FED_TAX_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_FED_TAX_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PCP_CAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PLN_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PLN_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PVDRPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_PVDRTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_SPLRTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_UPN_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PRV_UPN_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYPD_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYPD_CNCTINFOPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYPD_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYPD_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYPD_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYRL_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYRL_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYRL_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYRL_PAYR_USR_ROLS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYRL_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYRL_USR_ROLS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYSD_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYSS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYSS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYSS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYSS_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYSS_SRVCSCTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_PYSS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QSS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QSS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QSS_DFLTUI_PFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QSS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QSS_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QSS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_DSCN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_DSCN_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_DSCN_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_URL_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_REPT_URL_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RERT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RERT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RERT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RERT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RETA_ACTLRCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RETA_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RETA_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RETA_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RETA_TRKGFOR_RCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RETA_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RLCT_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RLST_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RLST_CNRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RLST_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RLST_LANG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RLST_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RLST_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ROID_ROTYP_WTSK_WCST_OSTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ROTYP_ROID_OBJ_STT_WTSK_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RSCF_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RUFU_AUMTRTNGRULE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RUFU_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RUFU_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RUFU_FLBKUSRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RUFU_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RUFU_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_CFRDREVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_FRTROPNNFOR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_OGTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_RESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_RET_TO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_RFRDOBJ_ID_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_SNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWHD_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_HEAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_RFRDOBJ_ID_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_RJTNRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RWRC_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SACT_ALT_COSTTYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SACT_ALT_COSTUNITTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SACT_ALT_SRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SACT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SACT_COSTBEN_EXCGSVGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SACT_COSTDENLSVGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SACT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SACT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SACT_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SACT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_CAT_SUB_CAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_CM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_MDCLSRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_SVGSCAT_DTLS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_SVGSMEMBDGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SAV_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SCBT_CAREBEANTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SCBT_CB_SETK_TMTD_AFFM_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SCBT_CB_STK_TD_AFM_NVL_PRNL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_EDNLCNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SELC_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SERS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SERS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SERS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SERS_RCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SERS_SENTEMAL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SERS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CNCLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_ORIGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_OWNRORIGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_REPP_STARTDATEALL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_RETNPTRN_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_SENT_Y2D'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_SRC__ASMTCARECALC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_SRC__PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_STARTDATEALL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_STRTSNLTDT_LOWB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TAKNASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TMTD_HIGHB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TMTD_HIGHBX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TSK_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SKC4CID_SKID_SKTSKNM_CT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_AFFN_APL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_AFFN_MDCLSRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_AFFN_UM_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_CNTT_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_ENLPBACK_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_ENLPFRNT_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_FAX_COVRPAGE_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_LBL__CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_PRPDLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_SNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SLTT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SNTS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SNTS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SNTS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SNTS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SRVS_RQTDSRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SRVS_RQTDSRVCPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SSDT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SSDT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SSDT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SSDT_STNG_DFLTDAT_BOLNVAL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SSDT_STNG_DFLTDAT_ITGRVAL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SSDT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_RTKNORIG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_SENTLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_CAREBEAN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_LAS_GKPR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_ORIGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_SENT_Y2D'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_SRC__ASMTCARECALC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_SRC__PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_TAKNASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_TAKNASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CNXT_APL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CNXT_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CNXT_MDCLSRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CNXT_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CNXT_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CNXT_UM_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CNXT_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CNXT_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CNXT_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_GRP_CNXT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STEL_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STNT_ID_DDLI_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_CNTT_CNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_CNTT_CONTIMG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_CNTT_CONTIMG_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_CNTT_CONTIMG_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_CNTT_CONTLTRH'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_CNTT_CONTLTRH_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_CNTT_CONTLTRH_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_ENVCMT_LBLCMT_PRUS_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_ENVCMT_LBLCMT_PRUS_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_FAXCMT_PRUS_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_FAXCMT_PRUS_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STTY_VSBT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SVCD_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SVCD_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SVCD_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SVCD_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SVDC_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SVDC_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SVDC_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SVDC_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SVDC_SRVC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SVDC_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_ASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_CLLDSTTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_CURRQTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TELEPHONE_FK_PRV_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_KWDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_KWDS_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_KWDS_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_NAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_TSK_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TKBS_VSBT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TMDS_CAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TMDS_RULENAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TMDS_RULENAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TMDS_RULENAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_PAYRMY_TO_RQS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_REQTTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOFR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOIT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOIT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOIT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOIT_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOIT_TIM_OFF_REQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TOIT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_ORIGOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_RCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_RESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_RFRDOBJ_ID_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_RFRDOBJ_ID_TYP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_RJTNRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_SNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TRRC_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TSKT_ICON'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TSKT_RCPTTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_APVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TTLT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TYP_TYP_OBJ_STT_ID_CURRSTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_T_APBL_APBL_UMEVENT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_T_APBL_MSDG_MID_CT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UBIO_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UBIO_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UBIO_INP_BY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UBIO_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UBIO_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UBIO_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UBIO_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCRP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCRP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCRP_CSFN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCRP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCRP_RQNGPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCRP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCSP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCSP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCSP_CSFN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCSP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCSP_SENGPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCSP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_BIZA_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_CNCTMTHD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_CONF_ADDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_HOMA_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_ID_BIZ_ADD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_ID_HOM_ADD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_PAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_PRFSEMAL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_PRFSMAIL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_PRFSPHNE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UCTI_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UENR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UENR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UENR_NTCERCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UENR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UENR_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UENR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ULGN_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ULGN_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ULGN_MRBLPHRSCHNG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ULGN_NTLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ULGN_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_ULGN_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMAD_UMBS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_ID_RQNGPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_LTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OWNROBST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OWNR_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_OWNR_STT_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_PFNGPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_PITY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_PMRYPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RQNGPVDRNODELMEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RQTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RTNGPEER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_RTNGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_SRC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_SVTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMBS_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMDS_DGISUMEVNT_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMDS_SNP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_DENLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_FRSTSBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_LAS_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_RJTNRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMER_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_CLSRRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_FRSTOPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_CLSDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_REVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_RPNDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_LAS_RTEDTO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_RCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_REONRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_REQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMET_UM_EVNTOTCM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMNR_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMNR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMNR_NTCERCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMNR_NTCEUM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMNR_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMNR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_DCLYXTDD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_MNLYDRMDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRNTEVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMXT_XTDD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UPAS_PVDRUM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_CNCTINFO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_ECTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_FRSTATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_FRSTNAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_FRSTNAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_IDNODELMSTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_LAS_ATVDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_LAS_DCTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_LAS_NAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MDLENAM_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MDLENAM_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MRGEMSTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_MRGEMSTR_MBUR_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_NAM_PRFX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_NAM_SFIX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PMRYLANG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_RATNAPVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_SBTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_USR_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WKFWTSK_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSC_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSC_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSC_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSC_OGTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSC_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSC_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSC_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSC_PRVSSTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSC_TSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSC_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSK_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSK_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSK_CURRSTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSK_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSK_RFRDOBJ_ID_TYP_TYP_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSK_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSK_TSK_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_WTSK_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'I_MLOG$_T_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTCMBBX6'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTCMBBX7'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTDGISX8'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTMEMBDGISX5'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTUMBBX1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_CLINICALDATA_ASSN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_CLINICALDATA_AUTH_ASSN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_COORDINATION_OF_BENEFITS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_IHCIS_RISK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_INSURANCE_IDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_ALRT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_APBL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_APL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_APVLHEAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_APVLREC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_APVLTRKGDEND'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_ASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_BARRIER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_BARRIER_TEMPLATE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_BLR_PLT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CAREBEANBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CAREBEANRCTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CAREPLAN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CFRDREVW'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CFTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CM_BASEBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CM_CSFNPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CM_NTCERCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CNCT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CNRTSRVCFEES'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CNRTSRVCFEE_HNTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_CSTMWKLDLMIT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_DAT_ACC_RTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_DAYSOFF_AWNC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_DDL_ITEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_DDL_ITEMPVDRSLTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_DDL_ITEMPVDRSSPS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_DGRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_DRUGCLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_EDNLCNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_ENNS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_FAX_CSFNCASEPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_FAX_CSFNMEMBPCP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_FAX_CSFNPFNGPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_FAX_CSFNRQNGPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_FIL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_FRDSAND_FMLYLIST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_FRTSFDRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_GOALCP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_GOALCP_TEMPLATE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_GRIEVANCE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_GRP_MEMS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_ICMGFAX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_LCNSLIST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_LNGSLIST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_LTR_HEAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_LTR_RCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_LTR_SUBJ'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_LTR_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_LWSTCOSTPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_MDCLCLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_MDCLREC_CSFNMEMS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_MDCT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_MEMBCTCS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_MEMBDGISBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_MEMBPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_MEMBPCP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_NOTE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_NTCE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_ORG_CHRTITEM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_ORG_CHRTITEMPRSS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_OUTCOME'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PAYRDGISSCTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PAYRPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PAYRROLS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PAYRSRVCSCTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PHI'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PRMR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PRODCAT_CNTDPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PRODCAT_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PROVIDER_CHOICE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PRPDLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PRSC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PVDRADVEGRP_PVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PVDRAFFDHPTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PVDRAFFDPHYS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PVDRASTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PVDRPAYRDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PVDRPLNSAFFS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PVDR_DIR_DETS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_PVRSRQRGAUTH'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_QCK_SEA_SNGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_REP_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_REVWHEAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_REVWRCPTTRKG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_REVWREC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_REVWTRKGACTL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_RGNLSNGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_RSLSCNFG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_RTNGFLBKUSRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SENTCAREBEAN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SENTEDNLCNTT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SENTEMAL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SENTEMALRCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SENTLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SNRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SRVCDVONCNTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_STCYNOTESNGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SVGS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SVGSALT_COST'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SVGSCAT_DTLS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SYTMSTNGDAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_TAKNASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_TIM_OFF_ITVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_TIM_OFF_REQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_TNFRREC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_TODO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_TODO_TEMPLATE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_TSK_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_UM_CSFNRQNGPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_UM_CSFNSENGPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_UM_EXTNNTCERCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_UM_NTCERCTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_USR_BIOS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_USR_CNCTINFO'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_USR_LOGN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_WKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_WKFWTSK_STT_CNGE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_XMPTPVRS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_UGDX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_UGRX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0015722'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0015724'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0015725'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0015728'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0015729'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0015732'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0015735'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0015736'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0015819'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0018091'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0018099'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0021663'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0021670'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0021685'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0021700'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0021737'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_C0022625'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000115282C00051$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116425C00018$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116425C00019$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116430C00018$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116451C00016$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116466C00016$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116466C00017$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116474C00019$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116477C00021$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116483C00018$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116486C00016$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116489C00019$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116492C00016$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116495C00016$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116722C00010$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000116722C00017$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000522260C00008$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_APBL_UX_PRNTEVNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_APVLREC_IX_TUNE1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_APVLREC_IX_TUNE2'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_CFPRBLMDS_THE_BRNCACT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_DDL_ITEM_IX_DDLI_LBL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_PRMR_IX_PERF_USR_STTDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_REVWREC_IX_RWRC_RFRDOBJ_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_REVWREC_IX_TUNE1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_REVWREC_IX_TUNE2'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTSK_UX_EVNTREQT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_CM_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_EVNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_EXTN_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_ORIG_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_TSK_BASE_TKBS_ID_CTSK_ORIG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_CLSTYP_MRGE_LAS_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_MBUR_SCL_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_OBJ_STT2_MRGMSTR_NULL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_PAYR_SSN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_PRV_PLN_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_TUNE1'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_TUNE2'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_C4C_ID_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_NAM3'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_IX_USR_NAM4'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_LOGN_IX_ULGN_USR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_USR_SPEC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_WKFWTSK_IX_WTSK_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_WKFWTSK_IX_WTSK_RFRDOBJ_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ABPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ADRN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_AHNS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_APRT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ASMCCB_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ASMT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ATTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_BARRIER_BARRIER_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_BLRN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_BLRPLT_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_BMTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_BPTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_BSGD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_BXES'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_BXSV'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CBDG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CBS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CBTE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CCBN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CCLC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CCTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CCTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CDRN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CDSS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CDTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CFDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CFPRBLMDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CLINICALDATA_ASSN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CLINICALDATA_AUTH_ASSN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMBS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMDI'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMPB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMPQ'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMPR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMTB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CNTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_COB_MEMBER_CARRIER_RANK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CPAS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CPNY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CRQB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CRTB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CSFE_SRVCPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CSFH_SRVCPVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CSRQ'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CTRN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CTYB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CYSD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_DESD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_DIAG_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_DIRN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_DLIR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_DLSD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_DNSV'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_DSSD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_EDNLCNTT_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ENVL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ETTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_EUCY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_FAXC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_FCTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_FF'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_GOALCP_GOAL_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_IC10D'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_IC9D'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ILSD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_IMDY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_IPGR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_ISTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LBL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LHFL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LHTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LLTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LSGD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LTRTMPT_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LTSD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_LTTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MBUR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MDSS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MMGY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MNTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MPAS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MRSV'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MRWH'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MSPA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MSRV'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_NCTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_OCHI_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_OSAV'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_OURS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PAYR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PCNS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PCRT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PDSS_PRBL_NAME'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PIDQ_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PIQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PLNS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PRNY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PRRN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PRV'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PTTP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_PYSD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_QTYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_RLCT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_RNRN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_RPTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_RSCF_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_SCBT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_SCNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_SGSD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_SNRY_ENV_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_SRVS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_STAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_TITY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_TMDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_TODO_TODO_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_TSKBASE_NAM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_TSKT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_TTLT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_T_UM_BASE_UMBS_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UENY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMER'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMET'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMXT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UPAS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UNIVERSALID_UN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'USR_DEVICE_UNIQUE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;

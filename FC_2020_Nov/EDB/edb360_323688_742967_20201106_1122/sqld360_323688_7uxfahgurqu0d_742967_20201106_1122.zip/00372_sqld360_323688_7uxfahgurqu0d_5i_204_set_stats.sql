/*
* This script includes all the commands to set basic level (table, index and columns) stats
* It is intentionally simple to ensure it completes quickly but at the same time allows to change stats easily enough
* Objects are expected in current schema, otherwise just chance the owner with whatever you need
*/

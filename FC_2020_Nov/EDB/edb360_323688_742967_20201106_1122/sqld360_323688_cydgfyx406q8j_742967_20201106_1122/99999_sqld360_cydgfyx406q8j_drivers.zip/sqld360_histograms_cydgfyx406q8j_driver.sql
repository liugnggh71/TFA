SET PAGES 50000
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column A_APBL.APBL_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175 * 753175) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175 * 753175)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''APBL_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_APBL.APBL_DTMN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175 * 753175) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175 * 753175)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''APBL_DTMN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_APBL.APBL_IS_ERR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 355249 * 355249) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 355249,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 355249 * 355249)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 355249 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''APBL_IS_ERR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_APBL.MSRV_MDCLSRVCTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503773 * 503773) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503773,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503773 * 503773)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503773 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''MSRV_MDCLSRVCTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_APBL.MSRV_PLCEOF_SRVCTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 483826 * 483826) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 483826,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 483826 * 483826)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 483826 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''MSRV_PLCEOF_SRVCTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_APBL.MSRV_BED_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 160170 * 160170) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 160170,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 160170 * 160170)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 160170 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''MSRV_BED_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_APBL.APBL_DENLRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 126466 * 126466) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 126466,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 126466 * 126466)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 126466 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''APBL_DENLRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_APBL.APBL_RQTDUNTS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 752105 * 752105) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 752105,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 752105 * 752105)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 752105 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''APBL_RQTDUNTS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_APBL.UMXT_XTDD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 1792 * 1792) rows_per_bucket,
trunc(endpoint_repeat_count / 1792,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 1792 * 1792)||'' Sel: ''||trunc(endpoint_repeat_count / 1792,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''UMXT_XTDD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_APBL.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175 * 753175) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175 * 753175)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 753175 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_APBL.VALID_FROM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 16690 * 753175) rows_per_bucket,
trunc(endpoint_repeat_count / 16690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 16690 * 753175)||'' Sel: ''||trunc(endpoint_repeat_count / 16690,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''VALID_FROM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_APBL.VALID_TO'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5513 * 249414) rows_per_bucket,
trunc(endpoint_repeat_count / 5513,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5513 * 249414)||'' Sel: ''||trunc(endpoint_repeat_count / 5513,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''VALID_TO''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_APBL.APBL_DET_RSN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 48 * 48) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 48,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 48 * 48)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 48 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''APBL_DET_RSN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_APBL.MSRV_LEVEL_OF_SERV'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6 * 6) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6 * 6)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_APBL''
AND a.column_name = ''MSRV_LEVEL_OF_SERV''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CASE_CLSRRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 729470 * 729470) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 729470,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 729470 * 729470)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 729470 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CASE_CLSRRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CASE_PRJ_OTCM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 53551 * 53551) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 53551,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 53551 * 53551)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 53551 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CASE_PRJ_OTCM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CASE_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397046 * 397046) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397046,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397046 * 397046)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397046 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CASE_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CASE_PRVSOWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 271386 * 271386) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 271386,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 271386 * 271386)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 271386 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CASE_PRVSOWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CASE_REONRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2434 * 2434) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2434,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2434 * 2434)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2434 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CASE_REONRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMPQ_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 36 * 36) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 36,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 36 * 36)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 36 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMPQ_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMPR_CLSRRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1979 * 1979) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1979,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1979 * 1979)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1979 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMPR_CLSRRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMPR_PRJ_OTCM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 500 * 500) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 500,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 500 * 500)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 500 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMPR_PRJ_OTCM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMPR_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2456682 * 2456682) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2456682,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2456682 * 2456682)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2456682 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMPR_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMPR_PRVSOWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2043762 * 2043762) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2043762,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2043762 * 2043762)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2043762 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMPR_PRVSOWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMBB_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 529359 * 529359) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 529359,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 529359 * 529359)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 529359 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMBB_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMBB_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3939069 * 3939069) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3939069,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3939069 * 3939069)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3939069 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMBB_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMBB_RESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3934134 * 3934134) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3934134,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3934134 * 3934134)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3934134 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMBB_RESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMBB_PITY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3826149 * 3826149) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3826149,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3826149 * 3826149)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3826149 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMBB_PITY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMBB_SVTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3855025 * 3855025) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3855025,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3855025 * 3855025)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3855025 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMBB_SVTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_CM_BASEBASE.CMBS_MEMB'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 6333 * 3971276) rows_per_bucket,
trunc(endpoint_repeat_count / 6333,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 6333 * 3971276)||'' Sel: ''||trunc(endpoint_repeat_count / 6333,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMBS_MEMB''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 * 3971276) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 * 3971276)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMBB_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 * 3971276) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 * 3971276)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMBB_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMBB_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 * 3971276) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 * 3971276)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMBB_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMBB_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 * 3971276) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 * 3971276)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3971276 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMBB_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CMPQ_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 36 * 36) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 36,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 36 * 36)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 36 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CMPQ_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.CSRQ_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 144697 * 144697) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 144697,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 144697 * 144697)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 144697 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''CSRQ_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_CM_BASEBASE.VALID_FROM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 6333 * 3971276) rows_per_bucket,
trunc(endpoint_repeat_count / 6333,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 6333 * 3971276)||'' Sel: ''||trunc(endpoint_repeat_count / 6333,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''VALID_FROM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.PARTICIPATION'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 120706 * 120706) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 120706,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 120706 * 120706)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 120706 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''PARTICIPATION''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.REQUESTOR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 131486 * 131486) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 131486,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 131486 * 131486)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 131486 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''REQUESTOR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.STAGE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 140097 * 140097) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 140097,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 140097 * 140097)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 140097 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''STAGE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.TGT_INTERVENTION'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 133134 * 133134) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 133134,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 133134 * 133134)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 133134 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''TGT_INTERVENTION''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_CM_BASEBASE.PARTICIPATIONSTATUS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 126830 * 126830) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 126830,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 126830 * 126830)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 126830 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_CM_BASEBASE''
AND a.column_name = ''PARTICIPATIONSTATUS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column A_MEMBDGISBASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 929421 * 929421) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 929421,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 929421 * 929421)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 929421 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_MEMBDGISBASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_MEMBDGISBASE.MBDB_C4C_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7470 * 894610) rows_per_bucket,
trunc(endpoint_repeat_count / 7470,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7470 * 894610)||'' Sel: ''||trunc(endpoint_repeat_count / 7470,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_MEMBDGISBASE''
AND a.column_name = ''MBDB_C4C_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_MEMBDGISBASE.MBDB_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 929421 * 929421) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 929421,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 929421 * 929421)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 929421 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_MEMBDGISBASE''
AND a.column_name = ''MBDB_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_MEMBDGISBASE.MDSS_IS_ERR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 423799 * 423799) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 423799,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 423799 * 423799)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 423799 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_MEMBDGISBASE''
AND a.column_name = ''MDSS_IS_ERR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_MEMBDGISBASE.MBDB_DGIS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7729 * 927688) rows_per_bucket,
trunc(endpoint_repeat_count / 7729,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7729 * 927688)||'' Sel: ''||trunc(endpoint_repeat_count / 7729,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_MEMBDGISBASE''
AND a.column_name = ''MBDB_DGIS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_MEMBDGISBASE.UMAD_UMBS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 296 * 296) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 296,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 296 * 296)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 296 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_MEMBDGISBASE''
AND a.column_name = ''UMAD_UMBS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column A_PVDRASTN.PRAS_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6142 * 9079113) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6142,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6142 * 9079113)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6142 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_PVDRASTN''
AND a.column_name = ''PRAS_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_PVDRASTN.CPAS_CM_BASE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43 * 43) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43 * 43)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_PVDRASTN''
AND a.column_name = ''CPAS_CM_BASE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_PVDRASTN.PRAS_PVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 6144 * 9078902) rows_per_bucket,
trunc(endpoint_repeat_count / 6144,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 6144 * 9078902)||'' Sel: ''||trunc(endpoint_repeat_count / 6144,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_PVDRASTN''
AND a.column_name = ''PRAS_PVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_PVDRASTN.PRAS_AUDIT_KEY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 89 * 89) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 89,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 89 * 89)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 89 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_PVDRASTN''
AND a.column_name = ''PRAS_AUDIT_KEY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column A_UM_BASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 * 581786) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 * 581786)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 * 581786) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 * 581786)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 * 581786) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 * 581786)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 * 581786) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 * 581786)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_DDLNTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 337056 * 337056) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 337056,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 337056 * 337056)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 337056 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_DDLNTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_REQTTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 * 581786) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 * 581786)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581786 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_REQTTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_DRVDDTMNSTT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581773 * 581773) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581773,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581773 * 581773)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 581773 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_DRVDDTMNSTT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMER_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 214 * 214) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 214,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 214 * 214)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 214 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMER_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMET_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 562967 * 562967) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 562967,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 562967 * 562967)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 562967 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMET_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMET_PRVSOWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 175900 * 175900) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 175900,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 175900 * 175900)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 175900 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMET_PRVSOWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMER_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 214 * 214) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 214,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 214 * 214)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 214 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMER_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMET_UM_EVNTOTCM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 19060 * 19060) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 19060,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 19060 * 19060)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 19060 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMET_UM_EVNTOTCM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMET_CLSRRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 357907 * 357907) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 357907,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 357907 * 357907)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 357907 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMET_CLSRRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_SVTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 106 * 106) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 106,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 106 * 106)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 106 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_SVTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_PITY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2116 * 2116) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2116,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2116 * 2116)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2116 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_PITY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 336280 * 336280) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 336280,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 336280 * 336280)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 336280 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMET_REONRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 65103 * 65103) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 65103,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 65103 * 65103)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 65103 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMET_REONRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 571740 * 571740) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 571740,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 571740 * 571740)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 571740 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_UM_BASE.VALID_FROM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 9781 * 581786) rows_per_bucket,
trunc(endpoint_repeat_count / 9781,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 9781 * 581786)||'' Sel: ''||trunc(endpoint_repeat_count / 9781,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''VALID_FROM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_UM_BASE.VALID_TO'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5639 * 331096) rows_per_bucket,
trunc(endpoint_repeat_count / 5639,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5639 * 331096)||'' Sel: ''||trunc(endpoint_repeat_count / 5639,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''VALID_TO''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_AUTH_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6 * 6) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6 * 6)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_AUTH_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_UM_BASE.UMBS_AUTH_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7 * 7) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7 * 7)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_UM_BASE''
AND a.column_name = ''UMBS_AUTH_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column A_USR.PAYR_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 3749 * 3749) rows_per_bucket,
trunc(endpoint_repeat_count / 3749,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 3749 * 3749)||'' Sel: ''||trunc(endpoint_repeat_count / 3749,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''PAYR_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_USR.USR_ECTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2522758 * 2522758) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2522758,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2522758 * 2522758)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2522758 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''USR_ECTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_USR.USR_NAM_SFIX'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 127322 * 127322) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 127322,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 127322 * 127322)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 127322 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''USR_NAM_SFIX''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_USR.USR_NAM_PRFX'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2338360 * 2338360) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2338360,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2338360 * 2338360)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2338360 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''USR_NAM_PRFX''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_USR.MBUR_RLSPTO_SBCR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5600607 * 5600607) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5600607,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5600607 * 5600607)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5600607 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''MBUR_RLSPTO_SBCR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_USR.USR_MRGEMSTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 458 * 458) rows_per_bucket,
trunc(endpoint_repeat_count / 458,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 458 * 458)||'' Sel: ''||trunc(endpoint_repeat_count / 458,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''USR_MRGEMSTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_USR.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8814981 * 8814981) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8814981,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8814981 * 8814981)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8814981 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_USR.USR_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126 * 8815126) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126 * 8815126)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''USR_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_USR.USR_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126 * 8815126) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126 * 8815126)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''USR_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_USR.USR_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126 * 8815126) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126 * 8815126)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8815126 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''USR_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column A_USR.USR_GNDRCODE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5754487 * 5754487) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5754487,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5754487 * 5754487)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5754487 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''USR_GNDRCODE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_USR.VALID_FROM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 16342 * 8815126) rows_per_bucket,
trunc(endpoint_repeat_count / 16342,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 16342 * 8815126)||'' Sel: ''||trunc(endpoint_repeat_count / 16342,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''VALID_FROM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column A_USR.VALID_TO'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 12751 * 6828979) rows_per_bucket,
trunc(endpoint_repeat_count / 12751,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 12751 * 6828979)||'' Sel: ''||trunc(endpoint_repeat_count / 12751,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''A_USR''
AND a.column_name = ''VALID_TO''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00150_sqld360_323688_cydgfyx406q8j_3a_67_histograms.html APP;
PRO </td>

BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 91306
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_16777216_09192020025413_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 112847
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_33554433_09262020032400_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 236822
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_16777218_10312020025404_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 179279
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_16777216_10132020031032_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 245705
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_33554432_11032020025327_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 230019
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_16777216_10292020025436_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 233499
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_16777217_10302020030000_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 220745
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_33554433_10272020030554_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 242288
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_33554432_11022020025132_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 226571
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_33554432_10282020025428_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 255191
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_33554432_11062020025117_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 202349
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_cydgfyx406q8j_33554432_10212020030312_hist.html;
PRINT :myreport;
SPO OFF;

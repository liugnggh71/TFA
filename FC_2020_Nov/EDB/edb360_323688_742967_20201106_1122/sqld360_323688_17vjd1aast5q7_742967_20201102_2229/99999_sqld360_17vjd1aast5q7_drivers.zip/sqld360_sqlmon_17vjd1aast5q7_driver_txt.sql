BEGIN
:myreport :=
DBMS_SQLTUNE.report_sql_monitor
( sql_id => '17vjd1aast5q7'
, session_id => 4263
, session_serial => 15643
, sql_exec_start => TO_DATE('20201102192527', 'YYYYMMDDHH24MISS')
, sql_exec_id => 16777253
, inst_id => 1
, report_level => 'ALL'
, type => 'TEXT' );
END;
/
PRINT :myreport;
SPO sqld360_sqlmon_17vjd1aast5q7_16777253_20201102192527.txt;
PRINT :myreport;
SPO OFF;

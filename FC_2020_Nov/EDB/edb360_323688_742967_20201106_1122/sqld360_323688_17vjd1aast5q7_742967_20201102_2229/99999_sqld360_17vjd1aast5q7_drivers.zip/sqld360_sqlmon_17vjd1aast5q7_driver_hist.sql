BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 212703
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_33554444_10242020193253_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 198419
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_33554436_10192020193254_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 169818
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_33554457_10092020182627_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 160783
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_33554450_10062020182213_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 98874
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_33554436_09222020090211_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 209884
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_16777228_10232020193611_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 231941
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_16777239_10292020192613_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 235744
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_16777243_10302020192558_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 238815
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_16777247_10312020192534_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 190270
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_16777217_10162020182540_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 96303
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_33554433_09212020085923_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 214924
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_17vjd1aast5q7_33554446_10252020192220_hist.html;
PRINT :myreport;
SPO OFF;

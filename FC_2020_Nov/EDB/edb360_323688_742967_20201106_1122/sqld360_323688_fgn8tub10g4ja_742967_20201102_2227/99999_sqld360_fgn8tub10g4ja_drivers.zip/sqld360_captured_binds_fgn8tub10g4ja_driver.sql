SET PAGES 50000
SPO 00155_sqld360_323688_fgn8tub10g4ja_2g_55_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :1 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':1'
AND datatype_string = 'NUMBER'
AND sql_id = 'fgn8tub10g4ja'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :1 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':1'
AND datatype_string = 'NUMBER'
AND sql_id = 'fgn8tub10g4ja'
AND snap_id BETWEEN 1870 AND 4792
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :1 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':1'
AND datatype_string = 'NUMBER'
AND sql_id = 'fgn8tub10g4ja'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':1'
AND datatype_string = 'NUMBER'
AND sql_id = 'fgn8tub10g4ja'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 1870 AND 4792
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00155_sqld360_323688_fgn8tub10g4ja_2g_55_captured_binds_details.html APP;
PRO </td>

SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column CLAIM_REVIEW.PROVIDER_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 141 * 141) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 141,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 141 * 141)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 141 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''CLAIM_REVIEW''
AND a.column_name = ''PROVIDER_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_ALRT.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 * 186) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 * 186)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ALRT''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ALRT.ALRT_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 * 186) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 * 186)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ALRT''
AND a.column_name = ''ALRT_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ALRT.ALRT_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 * 186) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 * 186)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ALRT''
AND a.column_name = ''ALRT_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ALRT.ALRT_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 * 186) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 * 186)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ALRT''
AND a.column_name = ''ALRT_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ALRT.ALRT_OTCM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 * 186) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 * 186)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 186 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ALRT''
AND a.column_name = ''ALRT_OTCM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_APBL.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_APBL.APBL_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 503761) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 503761)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''APBL_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.APBL_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''APBL_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.APBL_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''APBL_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.APBL_DTMN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''APBL_DTMN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.APBL_IS_ERR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155388 * 155388) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155388,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155388 * 155388)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155388 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''APBL_IS_ERR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.MSRV_MDCLSRVCTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''MSRV_MDCLSRVCTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.MSRV_PLCEOF_SRVCTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 345702 * 345702) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 345702,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 345702 * 345702)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 345702 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''MSRV_PLCEOF_SRVCTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.MSRV_BED_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 117118 * 117118) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 117118,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 117118 * 117118)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 117118 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''MSRV_BED_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.APBL_DENLRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 42472 * 42472) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 42472,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 42472 * 42472)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 42472 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''APBL_DENLRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.APBL_ACTLUNTS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503686 * 503686) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503686,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503686 * 503686)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503686 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''APBL_ACTLUNTS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.APBL_APRDUNTS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503687 * 503687) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503687,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503687 * 503687)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503687 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''APBL_APRDUNTS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.APBL_RQTDUNTS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503687 * 503687) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503687,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503687 * 503687)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503687 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''APBL_RQTDUNTS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.APBL_DET_RSN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 42 * 42) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 42,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 42 * 42)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 42 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''APBL_DET_RSN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.MSRV_SRVC_AGRMNT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 * 503761)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 503761 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''MSRV_SRVC_AGRMNT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APBL.MSRV_LEVEL_OF_SERV'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APBL''
AND a.column_name = ''MSRV_LEVEL_OF_SERV''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_APL.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_DTMN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_DTMN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_APLD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_APLD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_APL_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_APL_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_APL_RESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_APL_RESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_DTRM_RESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 178 * 178) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 178,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 178 * 178)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 178 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_DTRM_RESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_PRTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_PRTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APL.APPL_RQT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 * 179)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 179 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APL''
AND a.column_name = ''APPL_RQT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_APVLHEAD.APHD_RFRDOBJ_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 * 10) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 * 10)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APVLHEAD''
AND a.column_name = ''APHD_RFRDOBJ_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APVLHEAD.APHD_RET_TO'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 * 10) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 * 10)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APVLHEAD''
AND a.column_name = ''APHD_RET_TO''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_APVLREC.APRC_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 * 10) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 * 10)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APVLREC''
AND a.column_name = ''APRC_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_APVLREC.APRC_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 * 10) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 * 10)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_APVLREC''
AND a.column_name = ''APRC_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_ASMTCC_BASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ASMTCC_BASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ASMTCC_BASE.ACCB_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ASMTCC_BASE''
AND a.column_name = ''ACCB_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ASMTCC_BASE.ACCB_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ASMTCC_BASE''
AND a.column_name = ''ACCB_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ASMTCC_BASE.ACCB_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ASMTCC_BASE''
AND a.column_name = ''ACCB_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ASMTCC_BASE.ACCB_NAM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ASMTCC_BASE''
AND a.column_name = ''ACCB_NAM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ASMTCC_BASE.ACCB_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ASMTCC_BASE''
AND a.column_name = ''ACCB_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ASMTCC_BASE.ASMT_TYP_SBTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ASMTCC_BASE''
AND a.column_name = ''ASMT_TYP_SBTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ASMTCC_BASE.(UPPER("THH_C4C"."REVERSE_STR"("ACCB_NAM")))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ASMTCC_BASE''
AND a.column_name = ''SYS_NC00064$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ASMTCC_BASE.(UPPER("ACCB_NAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 * 185)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ASMTCC_BASE''
AND a.column_name = ''SYS_NC00066$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_BARRIER.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 * 4892) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 * 4892)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BARRIER''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_BARRIER.BARRIER_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 * 4892) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 * 4892)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BARRIER''
AND a.column_name = ''BARRIER_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_BARRIER.BARRIER_VERS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 * 4892) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 * 4892)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BARRIER''
AND a.column_name = ''BARRIER_VERS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_BARRIER.BARRIER_STATUS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 * 4892) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 * 4892)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4892 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BARRIER''
AND a.column_name = ''BARRIER_STATUS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_BARRIER_TEMPLATE.BARRIER_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31 * 31) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31 * 31)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BARRIER_TEMPLATE''
AND a.column_name = ''BARRIER_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_BARRIER_TEMPLATE.BARRIER_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31 * 31) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31 * 31)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BARRIER_TEMPLATE''
AND a.column_name = ''BARRIER_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_BLR_PLT.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13 * 13) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13 * 13)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BLR_PLT''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_BLR_PLT.BP_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13 * 13) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13 * 13)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_BLR_PLT''
AND a.column_name = ''BP_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_CAREPLAN.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370 * 5370) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370 * 5370)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CAREPLAN''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_CAREPLAN.CP_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5370 * 5370) rows_per_bucket,
trunc(endpoint_repeat_count / 5370,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5370 * 5370)||'' Sel: ''||trunc(endpoint_repeat_count / 5370,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CAREPLAN''
AND a.column_name = ''CP_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CAREPLAN.CP_VERS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370 * 5370) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370 * 5370)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CAREPLAN''
AND a.column_name = ''CP_VERS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CAREPLAN.CP_STATUS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370 * 5370) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370 * 5370)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5370 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CAREPLAN''
AND a.column_name = ''CP_STATUS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 * 424774) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 * 424774)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_CM_BASEBASE.CMBB_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 424774) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 424774)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 * 424774) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 * 424774)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_CM_BASEBASE.CMBB_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 424774) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 424774)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 * 424774) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 * 424774)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 * 424774) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 * 424774)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 * 424774) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 * 424774)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 424774 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CSRQ_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44416 * 44416) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44416,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44416 * 44416)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44416 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CSRQ_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CASE_CLSRRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232249 * 232249) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232249,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232249 * 232249)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232249 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CASE_CLSRRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CASE_PRJ_OTCM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33166 * 33166) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33166,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33166 * 33166)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33166 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CASE_PRJ_OTCM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CASE_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 129884 * 129884) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 129884,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 129884 * 129884)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 129884 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CASE_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CASE_PRVSOWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 80516 * 80516) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 80516,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 80516 * 80516)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 80516 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CASE_PRVSOWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CASE_REONRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 520 * 520) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 520,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 520 * 520)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 520 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CASE_REONRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMPQ_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 * 18) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 * 18)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMPQ_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMPR_CLSRRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 838 * 838) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 838,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 838 * 838)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 838 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMPR_CLSRRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMPR_PRJ_OTCM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380 * 380) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380 * 380)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 380 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMPR_PRJ_OTCM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMPR_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250452 * 250452) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250452,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250452 * 250452)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250452 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMPR_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 169338 * 169338) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 169338,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 169338 * 169338)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 169338 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 413813 * 413813) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 413813,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 413813 * 413813)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 413813 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_RESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 412481 * 412481) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 412481,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 412481 * 412481)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 412481 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_RESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_PITY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 352741 * 352741) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 352741,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 352741 * 352741)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 352741 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_PITY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.CMBB_SVTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 377657 * 377657) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 377657,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 377657 * 377657)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 377657 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBB_SVTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_CM_BASEBASE.CMBS_MEMB'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 424774) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 424774)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''CMBS_MEMB''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.PARTICIPATION'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 41116 * 41116) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 41116,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 41116 * 41116)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 41116 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''PARTICIPATION''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.REQUESTOR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43900 * 43900) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43900,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43900 * 43900)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43900 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''REQUESTOR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.STAGE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 47654 * 47654) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 47654,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 47654 * 47654)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 47654 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''STAGE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.TGT_INTERVENTION'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44037 * 44037) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44037,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44037 * 44037)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 44037 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''TGT_INTERVENTION''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CM_BASEBASE.PARTICIPATIONSTATUS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43326 * 43326) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43326,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43326 * 43326)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43326 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''PARTICIPATIONSTATUS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_CM_BASEBASE.(UPPER("CMBB_C4C_ID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 424774) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 424774)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CM_BASEBASE''
AND a.column_name = ''SYS_NC00176$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_CNCT.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5442 * 789594) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5442,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5442 * 789594)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5442 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CNCT''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_CNCT.COAT_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5443 * 789594) rows_per_bucket,
trunc(endpoint_repeat_count / 5443,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5443 * 789594)||'' Sel: ''||trunc(endpoint_repeat_count / 5443,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CNCT''
AND a.column_name = ''COAT_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CNCT.COAT_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 789594 * 789594) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 789594,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 789594 * 789594)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 789594 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CNCT''
AND a.column_name = ''COAT_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CNCT.COAT_CNCTTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 787323 * 787323) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 787323,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 787323 * 787323)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 787323 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CNCT''
AND a.column_name = ''COAT_CNCTTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CNCT.COAT_CONTACT_RELATIONSHIP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1150 * 1150) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1150,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1150 * 1150)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1150 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CNCT''
AND a.column_name = ''COAT_CONTACT_RELATIONSHIP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_COORDINATION_OF_BENEFITS.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5342 * 44289) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5342,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5342 * 44289)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5342 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_COORDINATION_OF_BENEFITS''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_CSTMFLDS.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9993 * 2245083) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9993,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9993 * 2245083)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9993 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_CSTMFLDS.CSMF_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 9995 * 2245083) rows_per_bucket,
trunc(endpoint_repeat_count / 9995,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 9995 * 2245083)||'' Sel: ''||trunc(endpoint_repeat_count / 9995,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CSMF_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_CSTMFLDS.CSMF_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 9989 * 2243887) rows_per_bucket,
trunc(endpoint_repeat_count / 9989,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 9989 * 2243887)||'' Sel: ''||trunc(endpoint_repeat_count / 9989,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CSMF_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_CSTMFLDS.CSMF_UNIVID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5522 * 1238815) rows_per_bucket,
trunc(endpoint_repeat_count / 5522,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5522 * 1238815)||'' Sel: ''||trunc(endpoint_repeat_count / 5522,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CSMF_UNIVID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CSTMFLDS.CSMF_REF4'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60530 * 60530) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60530,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60530 * 60530)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60530 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CSMF_REF4''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CSTMFLDS.CSMF_REF1'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60473 * 60473) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60473,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60473 * 60473)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60473 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CSMF_REF1''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CSTMFLDS.CSMF_REF3'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 159927 * 159927) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 159927,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 159927 * 159927)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 159927 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CSMF_REF3''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CSTMFLDS.CSMF_REF2'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60528 * 60528) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60528,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60528 * 60528)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60528 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CSMF_REF2''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CSTMFLDS.CSMF_RF5'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5 * 5) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5 * 5)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CSMF_RF5''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CSTMFLDS.CSMF_RF6'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9817 * 9817) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9817,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9817 * 9817)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9817 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CSMF_RF6''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_CSTMFLDS.CSMF_RF9'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7977 * 7977) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7977,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7977 * 7977)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7977 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_CSTMFLDS''
AND a.column_name = ''CSMF_RF9''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column T_DAYSOFF_AWNC.DOAL_PAYR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 6121 * 6121) rows_per_bucket,
trunc(endpoint_repeat_count / 6121,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 6121 * 6121)||'' Sel: ''||trunc(endpoint_repeat_count / 6121,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DAYSOFF_AWNC''
AND a.column_name = ''DOAL_PAYR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_DDL_ITEM.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10192) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10192)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10229) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10229)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEM.DDLI_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEM.DDLI_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_UNIVID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_UNIVID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_LBL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_LBL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_VAL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_VAL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEM.DDLI_SYTM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10172 * 10172) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10172,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10172 * 10172)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10172 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_SYTM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_DDL_ITEMCONSID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 3398) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 3398)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_DDL_ITEMCONSID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEM.TSKT_RCPTTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 217 * 217) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 217,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 217 * 217)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 217 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''TSKT_RCPTTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_PRNT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 2301) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 2301)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_PRNT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_DDL_ITEM.DDLI_DDL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7763)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''DDLI_DDL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEM.("CLASSTYPE","DDLI_OBJ_STT")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 * 10372)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10372 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEM''
AND a.column_name = ''SYS_STS7_DOW3Y4SQ96_QSG9DVBTHW''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_DDL_ITEMPVDRSLTS.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5518 * 157753) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5518,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5518 * 157753)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5518 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEMPVDRSLTS''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_DDL_ITEMPVDRSLTS.DLIS_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5520 * 157753) rows_per_bucket,
trunc(endpoint_repeat_count / 5520,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5520 * 157753)||'' Sel: ''||trunc(endpoint_repeat_count / 5520,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEMPVDRSLTS''
AND a.column_name = ''DLIS_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DDL_ITEMPVDRSLTS.DLIS_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5518 * 157753) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5518,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5518 * 157753)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5518 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEMPVDRSLTS''
AND a.column_name = ''DLIS_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_DDL_ITEMPVDRSLTS.DLIS_SLTS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5519 * 157753) rows_per_bucket,
trunc(endpoint_repeat_count / 5519,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5519 * 157753)||'' Sel: ''||trunc(endpoint_repeat_count / 5519,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DDL_ITEMPVDRSLTS''
AND a.column_name = ''DLIS_SLTS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_DGIS.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 * 110315) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 * 110315)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_DGIS.DSS_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 6575 * 110315) rows_per_bucket,
trunc(endpoint_repeat_count / 6575,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 6575 * 110315)||'' Sel: ''||trunc(endpoint_repeat_count / 6575,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''DSS_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DGIS.DSS_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 * 110315) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 * 110315)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''DSS_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DGIS.DSS_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6574 * 110315) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6574,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6574 * 110315)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6574 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''DSS_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DGIS.DSS_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 * 110315) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 * 110315)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''DSS_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_DGIS.DSS_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 6576 * 110315) rows_per_bucket,
trunc(endpoint_repeat_count / 6576,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 6576 * 110315)||'' Sel: ''||trunc(endpoint_repeat_count / 6576,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''DSS_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DGIS.CDSS_NAM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232 * 232) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232 * 232)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''CDSS_NAM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DGIS.TMDS_CAT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 849 * 849) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 849,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 849 * 849)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 849 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''TMDS_CAT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DGIS.CDSS_TYP_SBTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232 * 232) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232 * 232)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''CDSS_TYP_SBTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DGIS.("CLASSTYPE","DSS_OBJ_STT")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 * 110315) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 * 110315)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 110315 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''SYS_STSPXD$934KZLXHWL3C885EZHT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_DGIS.(UPPER("CDSS_NAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232 * 232) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232 * 232)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 232 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_DGIS''
AND a.column_name = ''SYS_NC00073$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_EDNLCNTT.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 * 2538) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 * 2538)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_EDNLCNTT''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_EDNLCNTT.ECNT_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 * 2538) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 * 2538)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_EDNLCNTT''
AND a.column_name = ''ECNT_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_EDNLCNTT.ECNT_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 * 2538) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 * 2538)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_EDNLCNTT''
AND a.column_name = ''ECNT_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_EDNLCNTT.ECNT_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 * 2538) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 * 2538)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_EDNLCNTT''
AND a.column_name = ''ECNT_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_EDNLCNTT.ECNT_FIL_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 * 2538) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 * 2538)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2538 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_EDNLCNTT''
AND a.column_name = ''ECNT_FIL_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_EDNLCNTT.ECNT_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 324 * 324) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 324,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 324 * 324)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 324 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_EDNLCNTT''
AND a.column_name = ''ECNT_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_EDNLCNTT.(UPPER("ECNT_NAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 324 * 324) rows_per_bucket,
trunc(endpoint_repeat_count / 324,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 324 * 324)||'' Sel: ''||trunc(endpoint_repeat_count / 324,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_EDNLCNTT''
AND a.column_name = ''SYS_NC00068$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_ENNS.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14685568 * 14685568) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14685568,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14685568 * 14685568)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14685568 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685568) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685568)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ENNS.ELNS_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14685568 * 14685568) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14685568,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14685568 * 14685568)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 14685568 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_UNIVID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685568) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685568)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_UNIVID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_ENLTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685567) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685567)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_ENLTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_EFTVDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685567) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685567)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_EFTVDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_DSNTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 12938679) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 12938679)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_DSNTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_TERMDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 12976659) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 12976659)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_TERMDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_BENSPKG'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14633798) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14633798)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_BENSPKG''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_INSCPRSRGRP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685567) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685567)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_INSCPRSRGRP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.ELNS_PVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7208195) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7208195)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''ELNS_PVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.(TRUNC("ELNS_ENLTDT"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685567) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685567)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''SYS_NC00030$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_ENNS.(TRUNC(NVL("ELNS_DSNTDT",TO_DATE(' 9999-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685568) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 14685568)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''SYS_NC00031$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ENNS.(DECODE("ELNS_OBJ_STT",2,NULL,'1'))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2380152 * 2380152) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2380152,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2380152 * 2380152)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2380152 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ENNS''
AND a.column_name = ''SYS_NC00032$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_FIL.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13046 * 134195) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13046,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13046 * 134195)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13046 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_FIL''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_FIL.FILE_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 134195 * 134195) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 134195,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 134195 * 134195)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 134195 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_FIL''
AND a.column_name = ''FILE_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_FIL.FILE_FIL_NAM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 13048 * 134193) rows_per_bucket,
trunc(endpoint_repeat_count / 13048,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 13048 * 134193)||'' Sel: ''||trunc(endpoint_repeat_count / 13048,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_FIL''
AND a.column_name = ''FILE_FIL_NAM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_FIL.FILE_FIL_MEMBDGIS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 9602 * 9602) rows_per_bucket,
trunc(endpoint_repeat_count / 9602,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 9602 * 9602)||'' Sel: ''||trunc(endpoint_repeat_count / 9602,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_FIL''
AND a.column_name = ''FILE_FIL_MEMBDGIS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_FIL.FILE_PRPDLTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8 * 8) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8 * 8)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_FIL''
AND a.column_name = ''FILE_PRPDLTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_FRDSAND_FMLYLIST.FFL_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5420 * 291056) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5420,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5420 * 291056)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5420 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_FRDSAND_FMLYLIST''
AND a.column_name = ''FFL_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_FRDSAND_FMLYLIST.FFL_RLSPTO_MEMB'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5420 * 291054) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5420,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5420 * 291054)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5420 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_FRDSAND_FMLYLIST''
AND a.column_name = ''FFL_RLSPTO_MEMB''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_GOALCP.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 * 17788) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 * 17788)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_GOALCP.GOAL_TYP_SBTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9767 * 9767) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9767,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9767 * 9767)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9767 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP''
AND a.column_name = ''GOAL_TYP_SBTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_GOALCP.GOAL_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 17788 * 17788) rows_per_bucket,
trunc(endpoint_repeat_count / 17788,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 17788 * 17788)||'' Sel: ''||trunc(endpoint_repeat_count / 17788,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP''
AND a.column_name = ''GOAL_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_GOALCP.GOAL_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 * 17788) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 * 17788)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP''
AND a.column_name = ''GOAL_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_GOALCP.GOAL_VERS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 * 17788) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 * 17788)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP''
AND a.column_name = ''GOAL_VERS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_GOALCP.GOAL_STATUS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 * 17788) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 * 17788)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17788 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP''
AND a.column_name = ''GOAL_STATUS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_GOALCP_TEMPLATE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534 * 534) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534 * 534)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP_TEMPLATE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_GOALCP_TEMPLATE.GOAL_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 534 * 534) rows_per_bucket,
trunc(endpoint_repeat_count / 534,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 534 * 534)||'' Sel: ''||trunc(endpoint_repeat_count / 534,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP_TEMPLATE''
AND a.column_name = ''GOAL_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_GOALCP_TEMPLATE.GOAL_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534 * 534) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534 * 534)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP_TEMPLATE''
AND a.column_name = ''GOAL_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_GOALCP_TEMPLATE.GOAL_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534 * 534) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534 * 534)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 534 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP_TEMPLATE''
AND a.column_name = ''GOAL_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_GOALCP_TEMPLATE.GOAL_TYP_SBTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5 * 5) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5 * 5)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_GOALCP_TEMPLATE''
AND a.column_name = ''GOAL_TYP_SBTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_ICMGFAX.IFAX_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 125 * 125) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 125,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 125 * 125)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 125 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ICMGFAX''
AND a.column_name = ''IFAX_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ICMGFAX.IFAX_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 125 * 125) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 125,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 125 * 125)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 125 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ICMGFAX''
AND a.column_name = ''IFAX_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_LNGSLIST.LLT_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 427553 * 427553) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 427553,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 427553 * 427553)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 427553 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LNGSLIST''
AND a.column_name = ''LLT_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_LNGSLIST.LLT_LANGCODE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 427553 * 427553) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 427553,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 427553 * 427553)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 427553 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LNGSLIST''
AND a.column_name = ''LLT_LANGCODE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column T_LTR_RCPT.LRCP_USR_RCPT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 11633 * 11633) rows_per_bucket,
trunc(endpoint_repeat_count / 11633,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 11633 * 11633)||'' Sel: ''||trunc(endpoint_repeat_count / 11633,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_RCPT''
AND a.column_name = ''LRCP_USR_RCPT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_LTR_RCPT.LRCP_QUE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4 * 4) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4 * 4)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_RCPT''
AND a.column_name = ''LRCP_QUE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_LTR_SUBJ.LTSJ_AFFN_PVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 418 * 418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 418,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 418 * 418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 418 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_SUBJ''
AND a.column_name = ''LTSJ_AFFN_PVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_LTR_SUBJ.LTSJ_AFFN_CM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5011 * 5011) rows_per_bucket,
trunc(endpoint_repeat_count / 5011,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5011 * 5011)||'' Sel: ''||trunc(endpoint_repeat_count / 5011,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_SUBJ''
AND a.column_name = ''LTSJ_AFFN_CM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_LTR_SUBJ.LTSJ_AFFN_MEMB'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 3315 * 3315) rows_per_bucket,
trunc(endpoint_repeat_count / 3315,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 3315 * 3315)||'' Sel: ''||trunc(endpoint_repeat_count / 3315,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_SUBJ''
AND a.column_name = ''LTSJ_AFFN_MEMB''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_LTR_TMPT.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 * 404) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 * 404)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_TMPT''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_LTR_TMPT.LTLT_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 * 404) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 * 404)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_TMPT''
AND a.column_name = ''LTLT_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_LTR_TMPT.LTLT_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 * 404) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 * 404)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_TMPT''
AND a.column_name = ''LTLT_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_LTR_TMPT.LTLT_ASTNTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 * 404) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 * 404)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_TMPT''
AND a.column_name = ''LTLT_ASTNTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_LTR_TMPT.LTLT_TYP_SBTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 * 404) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 * 404)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 404 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_TMPT''
AND a.column_name = ''LTLT_TYP_SBTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_LTR_TMPT.LTLT_WEB_TMPT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 * 18) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 * 18)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_TMPT''
AND a.column_name = ''LTLT_WEB_TMPT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_LTR_TMPT.(UPPER("LTLT_NAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 404 * 404) rows_per_bucket,
trunc(endpoint_repeat_count / 404,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 404 * 404)||'' Sel: ''||trunc(endpoint_repeat_count / 404,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_LTR_TMPT''
AND a.column_name = ''SYS_NC00072$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column T_MDCLCLM.MCLM_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 10133 * 18630523) rows_per_bucket,
trunc(endpoint_repeat_count / 10133,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 10133 * 18630523)||'' Sel: ''||trunc(endpoint_repeat_count / 10133,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCLCLM.MCLM_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10131 * 18630523) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10131,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10131 * 18630523)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10131 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCLCLM.MCLM_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10131 * 18630523) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10131,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10131 * 18630523)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10131 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCLCLM.MCLM_CLM_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18630514 * 18630514) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18630514,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18630514 * 18630514)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18630514 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_CLM_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_MDCLCLM.MCLM_FRSTDT_OF_SRVC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 10133 * 18630503) rows_per_bucket,
trunc(endpoint_repeat_count / 10133,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 10133 * 18630503)||'' Sel: ''||trunc(endpoint_repeat_count / 10133,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_FRSTDT_OF_SRVC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_MDCLCLM.MCLM_LAS_DT_OF_SRVC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5371 * 10083638) rows_per_bucket,
trunc(endpoint_repeat_count / 5371,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5371 * 10083638)||'' Sel: ''||trunc(endpoint_repeat_count / 5371,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_LAS_DT_OF_SRVC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_MDCLCLM.MCLM_CPT4CODE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 10132 * 18630514) rows_per_bucket,
trunc(endpoint_repeat_count / 10132,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 10132 * 18630514)||'' Sel: ''||trunc(endpoint_repeat_count / 10132,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_CPT4CODE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_MDCLCLM.MCLM_ICD9DX1'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 10132 * 18630514) rows_per_bucket,
trunc(endpoint_repeat_count / 10132,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 10132 * 18630514)||'' Sel: ''||trunc(endpoint_repeat_count / 10132,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_ICD9DX1''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_MDCLCLM.MCLM_SENGPVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7424 * 13687022) rows_per_bucket,
trunc(endpoint_repeat_count / 7424,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7424 * 13687022)||'' Sel: ''||trunc(endpoint_repeat_count / 7424,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_SENGPVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Top-Frequency histogram on Column T_MDCLCLM.MCLM_RVNECODE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6869861 * 6869861) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6869861,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6869861 * 6869861)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6869861 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_RVNECODE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_MDCLCLM.MCLM_RFNGPVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5661 * 4047758) rows_per_bucket,
trunc(endpoint_repeat_count / 5661,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5661 * 4047758)||'' Sel: ''||trunc(endpoint_repeat_count / 5661,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCLCLM''
AND a.column_name = ''MCLM_RFNGPVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column T_MDCT.MDCT_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 25873 * 25873) rows_per_bucket,
trunc(endpoint_repeat_count / 25873,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 25873 * 25873)||'' Sel: ''||trunc(endpoint_repeat_count / 25873,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCT.MDCT_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 25873 * 25873) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 25873,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 25873 * 25873)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 25873 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCT.MDCT_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 25873 * 25873) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 25873,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 25873 * 25873)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 25873 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_MDCT.MDCT_STRTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 25873 * 25873) rows_per_bucket,
trunc(endpoint_repeat_count / 25873,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 25873 * 25873)||'' Sel: ''||trunc(endpoint_repeat_count / 25873,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_STRTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_MDCT.MDCT_END_DT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 3683 * 3683) rows_per_bucket,
trunc(endpoint_repeat_count / 3683,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 3683 * 3683)||'' Sel: ''||trunc(endpoint_repeat_count / 3683,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_END_DT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_MDCT.MDCT_AFFDREC__MEMB'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 13110 * 13110) rows_per_bucket,
trunc(endpoint_repeat_count / 13110,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 13110 * 13110)||'' Sel: ''||trunc(endpoint_repeat_count / 13110,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_AFFDREC__MEMB''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_MDCT.MDCT_NDC_CODE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 293 * 293) rows_per_bucket,
trunc(endpoint_repeat_count / 293,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 293 * 293)||'' Sel: ''||trunc(endpoint_repeat_count / 293,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_NDC_CODE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCT.MDCT_PRTDBY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 493 * 493) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 493,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 493 * 493)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 493 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_PRTDBY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCT.MDCT_DOSGUNIT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10725 * 10725) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10725,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10725 * 10725)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10725 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_DOSGUNIT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCT.MDCT_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11596 * 11596) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11596,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11596 * 11596)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11596 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCT.MDCT_ROUTE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1241 * 1241) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1241,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1241 * 1241)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1241 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_ROUTE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCT.MDCT_CURRENT_LIST'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1276 * 1276) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1276,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1276 * 1276)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1276 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_CURRENT_LIST''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCT.MDCT_SOURCE_OF_LIST'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1014 * 1014) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1014,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1014 * 1014)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1014 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_SOURCE_OF_LIST''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCT.MDCT_STATUS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 536 * 536) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 536,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 536 * 536)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 536 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_STATUS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MDCT.MDCT_REVIEWED_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 339 * 339) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 339,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 339 * 339)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 339 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MDCT''
AND a.column_name = ''MDCT_REVIEWED_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MBDB_C4C_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 380497) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 380497)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_C4C_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MBDB_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MBDB_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MBDB_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MBDB_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MBDB_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MDSS_STRTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 384675) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 384675)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_STRTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MDSS_END_DT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 18737) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 18737)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_END_DT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MDSS_IS_PMRYDGIS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 198641 * 198641) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 198641,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 198641 * 198641)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 198641 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_IS_PMRYDGIS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MDSS_IS_ERR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185207 * 185207) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185207,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185207 * 185207)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185207 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_IS_ERR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MDSS_SRC__ASMTCARECALC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1029 * 1029) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1029,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1029 * 1029)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1029 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_SRC__ASMTCARECALC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MBDB_DGIS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 396970) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 396970)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_DGIS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MDSS_CAUDBY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1025) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1025)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_CAUDBY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.UMAD_UMBS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 276 * 276) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 276,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 276 * 276)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 276 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''UMAD_UMBS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MPDS_PRBLM_STATUS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17818 * 17818) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17818,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17818 * 17818)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17818 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MPDS_PRBLM_STATUS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MPDS_PRBLM_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9726 * 9726) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9726,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9726 * 9726)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9726 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MPDS_PRBLM_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.("CLASSTYPE","MBDB_DGIS","MDSS_MEMB")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''SYS_STS16QW#IPBEJF$IE2_54ZF$HM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_NOTE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17632 * 958565) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17632,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17632 * 958565)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17632 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_NOTE.NOTE_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 17633 * 958565) rows_per_bucket,
trunc(endpoint_repeat_count / 17633,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 17633 * 958565)||'' Sel: ''||trunc(endpoint_repeat_count / 17633,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_NOTE.NOTE_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 17634 * 958565) rows_per_bucket,
trunc(endpoint_repeat_count / 17634,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 17634 * 958565)||'' Sel: ''||trunc(endpoint_repeat_count / 17634,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958565 * 958565) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958565,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958565 * 958565)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958565 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958565 * 958565) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958565,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958565 * 958565)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958565 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_PHNENOTE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10940 * 593401) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10940,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10940 * 593401)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10940 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_PHNENOTE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_UM_NOTETYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 461819 * 461819) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 461819,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 461819 * 461819)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 461819 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_UM_NOTETYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_PITY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118185 * 118185) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118185,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118185 * 118185)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118185 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_PITY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_CALLDRTNUNTS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10616 * 73168) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10616,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10616 * 73168)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10616 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_CALLDRTNUNTS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_CM_NOTETYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13466 * 13466) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13466,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13466 * 13466)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13466 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_CM_NOTETYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_CASENOTETYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 328838 * 328838) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 328838,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 328838 * 328838)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 328838 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_CASENOTETYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_MEMBNOTETYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 51648 * 51648) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 51648,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 51648 * 51648)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 51648 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_MEMBNOTETYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_SETK_NOTETYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 72283 * 72283) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 72283,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 72283 * 72283)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 72283 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_SETK_NOTETYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_CAREPLAN_NOTETYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15438 * 15438) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15438,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15438 * 15438)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15438 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_CAREPLAN_NOTETYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_SOURCE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 267300 * 267300) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 267300,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 267300 * 267300)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 267300 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_SOURCE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_REASON'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76600 * 76600) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76600,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76600 * 76600)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76600 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_REASON''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_CALL_OUTCOME'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 40453 * 40453) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 40453,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 40453 * 40453)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 40453 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_CALL_OUTCOME''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.NOTE_CALL_DISPOSITION'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 19109 * 19109) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 19109,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 19109 * 19109)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 19109 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_CALL_DISPOSITION''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_NOTE.NOTE_CONTACT_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 3291 * 3291) rows_per_bucket,
trunc(endpoint_repeat_count / 3291,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 3291 * 3291)||'' Sel: ''||trunc(endpoint_repeat_count / 3291,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_CONTACT_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NOTE.AFFILIATION_TYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958460 * 958460) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958460,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958460 * 958460)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958460 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''AFFILIATION_TYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Top-Frequency histogram on Column T_NOTE.NOTE_TYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958562 * 958562) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958562,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958562 * 958562)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 958562 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NOTE''
AND a.column_name = ''NOTE_TYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Height Balanced histogram on Column T_NTCE.NTC_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 118324) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 118324)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NTCE''
AND a.column_name = ''NTC_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NTCE.NTC_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 * 118324) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 * 118324)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NTCE''
AND a.column_name = ''NTC_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NTCE.NTC_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 * 118324) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 * 118324)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NTCE''
AND a.column_name = ''NTC_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NTCE.NTC_RFRDOBJ_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60237 * 60237) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60237,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60237 * 60237)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 60237 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NTCE''
AND a.column_name = ''NTC_RFRDOBJ_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_NTCE.NTC_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 118324) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 118324)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NTCE''
AND a.column_name = ''NTC_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NTCE.NTC_SENTBY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 * 118324) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 * 118324)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NTCE''
AND a.column_name = ''NTC_SENTBY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_NTCE.NTC_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 * 118324) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 * 118324)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 118324 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_NTCE''
AND a.column_name = ''NTC_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_ORG_CHRTITEM.OCHI_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8 * 8) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8 * 8)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ORG_CHRTITEM''
AND a.column_name = ''OCHI_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ORG_CHRTITEM.OCHI_LVL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8 * 8) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8 * 8)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 8 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ORG_CHRTITEM''
AND a.column_name = ''OCHI_LVL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_ORG_CHRTITEM.OCHI_PRNT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7 * 7) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7 * 7)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ORG_CHRTITEM''
AND a.column_name = ''OCHI_PRNT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_ORG_CHRTITEMPRSS.OCRP_PRSNCHRTITEM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 103 * 103) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 103,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 103 * 103)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 103 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_ORG_CHRTITEMPRSS''
AND a.column_name = ''OCRP_PRSNCHRTITEM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_OTHER_INSURANCE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5504 * 4310113) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5504,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5504 * 4310113)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5504 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_OTHER_INSURANCE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_OTHER_INSURANCE.INS_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5506 * 4310113) rows_per_bucket,
trunc(endpoint_repeat_count / 5506,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5506 * 4310113)||'' Sel: ''||trunc(endpoint_repeat_count / 5506,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_OTHER_INSURANCE''
AND a.column_name = ''INS_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_OUTCOME.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5483 * 31890) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5483,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5483 * 31890)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5483 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_OUTCOME''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_OUTCOME.OUTCOME_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5485 * 31890) rows_per_bucket,
trunc(endpoint_repeat_count / 5485,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5485 * 31890)||'' Sel: ''||trunc(endpoint_repeat_count / 5485,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_OUTCOME''
AND a.column_name = ''OUTCOME_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_OUTCOME.OUTCOME_VERS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31890 * 31890) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31890,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31890 * 31890)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31890 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_OUTCOME''
AND a.column_name = ''OUTCOME_VERS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_OUTCOME.OUTCOME_RESULT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31877 * 31877) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31877,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31877 * 31877)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 31877 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_OUTCOME''
AND a.column_name = ''OUTCOME_RESULT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_OUTCOME.OUTCOME_REASON'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 30759 * 30759) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 30759,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 30759 * 30759)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 30759 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_OUTCOME''
AND a.column_name = ''OUTCOME_REASON''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_PAT_ID_QRY.PIDQ_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11 * 11) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11 * 11)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PAT_ID_QRY''
AND a.column_name = ''PIDQ_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PAT_ID_QRY.PIDQ_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11 * 11) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11 * 11)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PAT_ID_QRY''
AND a.column_name = ''PIDQ_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_PAYRDGISSCTY.PDIS_PAYR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 463 * 463) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 463,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 463 * 463)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 463 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PAYRDGISSCTY''
AND a.column_name = ''PDIS_PAYR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PAYRDGISSCTY.PDIS_DGISSCTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 463 * 463) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 463,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 463 * 463)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 463 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PAYRDGISSCTY''
AND a.column_name = ''PDIS_DGISSCTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_PAYRROLS.PYRL_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 * 2223) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 * 2223)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PAYRROLS''
AND a.column_name = ''PYRL_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PAYRROLS.PYRL_PMRYROLE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 * 2223) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 * 2223)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PAYRROLS''
AND a.column_name = ''PYRL_PMRYROLE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PAYRROLS.PYRL_WKLDLMTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 * 2223) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 * 2223)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PAYRROLS''
AND a.column_name = ''PYRL_WKLDLMTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_PAYRROLS.PYRL_PAYR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 1508 * 1508) rows_per_bucket,
trunc(endpoint_repeat_count / 1508,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 1508 * 1508)||'' Sel: ''||trunc(endpoint_repeat_count / 1508,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PAYRROLS''
AND a.column_name = ''PYRL_PAYR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PAYRROLS.PYRL_USR_ROLS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 * 2223) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 * 2223)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2223 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PAYRROLS''
AND a.column_name = ''PYRL_USR_ROLS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column T_PHI.LAST_ACTION_TIME'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5505 * 737690) rows_per_bucket,
trunc(endpoint_repeat_count / 5505,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5505 * 737690)||'' Sel: ''||trunc(endpoint_repeat_count / 5505,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PHI''
AND a.column_name = ''LAST_ACTION_TIME''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PHI.PHI_TYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 737690 * 737690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 737690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 737690 * 737690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 737690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PHI''
AND a.column_name = ''PHI_TYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PHI.RELATIONSHIP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33511 * 33511) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33511,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33511 * 33511)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33511 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PHI''
AND a.column_name = ''RELATIONSHIP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PHI.PHONE_TYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 82323 * 82323) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 82323,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 82323 * 82323)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 82323 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PHI''
AND a.column_name = ''PHONE_TYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PHI.AUTH_SOURCE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 67 * 67) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 67,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 67 * 67)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 67 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PHI''
AND a.column_name = ''AUTH_SOURCE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PHI.AUTH_TYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5598 * 5598) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5598,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5598 * 5598)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5598 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PHI''
AND a.column_name = ''AUTH_TYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PHI.AUTH_PURPOSE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5598 * 5598) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5598,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5598 * 5598)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5598 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PHI''
AND a.column_name = ''AUTH_PURPOSE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PHI.CONF_COMM_TYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9 * 9) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9 * 9)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PHI''
AND a.column_name = ''CONF_COMM_TYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PHI.LEGAL_TYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33062 * 33062) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33062,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33062 * 33062)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 33062 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PHI''
AND a.column_name = ''LEGAL_TYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PHI.REP_TYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 699003 * 699003) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 699003,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 699003 * 699003)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 699003 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PHI''
AND a.column_name = ''REP_TYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column T_PRACTITIONER_ROLE.SUPPLIER_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 14517 * 116861) rows_per_bucket,
trunc(endpoint_repeat_count / 14517,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 14517 * 116861)||'' Sel: ''||trunc(endpoint_repeat_count / 14517,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRACTITIONER_ROLE''
AND a.column_name = ''SUPPLIER_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_PRACTITIONER_ROLE.SUPPLIER_LOCATION_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5327 * 43515) rows_per_bucket,
trunc(endpoint_repeat_count / 5327,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5327 * 43515)||'' Sel: ''||trunc(endpoint_repeat_count / 5327,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRACTITIONER_ROLE''
AND a.column_name = ''SUPPLIER_LOCATION_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PRACTITIONER_ROLE.OBJECT_STATE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 116861 * 116861) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 116861,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 116861 * 116861)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 116861 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRACTITIONER_ROLE''
AND a.column_name = ''OBJECT_STATE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Top-Frequency histogram on Column T_PRMR.PERF_USR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2447759 * 2447759) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2447759,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2447759 * 2447759)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2447759 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRMR''
AND a.column_name = ''PERF_USR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_PRODCAT_PVDR.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11276 * 76595628) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11276,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11276 * 76595628)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 11276 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRODCAT_PVDR''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PRODCAT_PVDR.PCPR_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628 * 76595628) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628 * 76595628)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRODCAT_PVDR''
AND a.column_name = ''PCPR_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PRODCAT_PVDR.APPLIES_TO_ALL_PRACTITIONERS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628 * 76595628) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628 * 76595628)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRODCAT_PVDR''
AND a.column_name = ''APPLIES_TO_ALL_PRACTITIONERS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PRODCAT_PVDR.BENEFIT_NETWORK_NAME'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628 * 76595628) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628 * 76595628)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 76595628 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRODCAT_PVDR''
AND a.column_name = ''BENEFIT_NETWORK_NAME''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column T_PROVIDER_CHOICE.PRCE_PVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5370 * 1227025) rows_per_bucket,
trunc(endpoint_repeat_count / 5370,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5370 * 1227025)||'' Sel: ''||trunc(endpoint_repeat_count / 5370,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PROVIDER_CHOICE''
AND a.column_name = ''PRCE_PVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_PRPDLTR.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 * 10977) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 * 10977)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRPDLTR''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_PRPDLTR.PRLT_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 10977 * 10977) rows_per_bucket,
trunc(endpoint_repeat_count / 10977,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 10977 * 10977)||'' Sel: ''||trunc(endpoint_repeat_count / 10977,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRPDLTR''
AND a.column_name = ''PRLT_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PRPDLTR.PRLT_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 * 10977) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 * 10977)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRPDLTR''
AND a.column_name = ''PRLT_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PRPDLTR.PRLT_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 * 10977) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 * 10977)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRPDLTR''
AND a.column_name = ''PRLT_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PRPDLTR.PRLT_ASTNTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 * 10977) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 * 10977)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRPDLTR''
AND a.column_name = ''PRLT_ASTNTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PRPDLTR.PRLT_TYP_SBTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 * 10977) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 * 10977)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10977 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRPDLTR''
AND a.column_name = ''PRLT_TYP_SBTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PRPDLTR.PRLT_LTR_TMPT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10654 * 10654) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10654,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10654 * 10654)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10654 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRPDLTR''
AND a.column_name = ''PRLT_LTR_TMPT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PRPDLTR.PRLT_QUE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10973 * 10973) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10973,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10973 * 10973)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10973 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PRPDLTR''
AND a.column_name = ''PRLT_QUE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_PVDRASTN.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271 * 2036271) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271 * 2036271)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_PVDRASTN.PRAS_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 2036271) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 2036271)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''PRAS_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_PVDRASTN.PRAS_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 2036271) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 2036271)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''PRAS_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PVDRASTN.PRAS_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271 * 2036271) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271 * 2036271)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''PRAS_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PVDRASTN.PRAS_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271 * 2036271) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271 * 2036271)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2036271 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''PRAS_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_PVDRASTN.PRAS_STRTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1227387) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1227387)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''PRAS_STRTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_PVDRASTN.PRAS_END_DT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1227344) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1227344)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''PRAS_END_DT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PVDRASTN.UPAS_RQNGPVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 303985 * 303985) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 303985,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 303985 * 303985)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 303985 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''UPAS_RQNGPVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PVDRASTN.UPAS_PFNGPVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 303985 * 303985) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 303985,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 303985 * 303985)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 303985 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''UPAS_PFNGPVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PVDRASTN.CPAS_CM_BASE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43 * 43) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43 * 43)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 43 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''CPAS_CM_BASE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PVDRASTN.PRAS_ROLE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1227373 * 1227373) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1227373,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1227373 * 1227373)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1227373 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''PRAS_ROLE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_PVDRASTN.PRAS_PVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 2036060) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 2036060)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''PRAS_PVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_PVDRASTN.PRAS_PRACTITIONER_LOCATION'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6 * 6) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6 * 6)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 6 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_PVDRASTN''
AND a.column_name = ''PRAS_PRACTITIONER_LOCATION''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_QCK_SEA_SNGS.QSS_DFLTUI_PFR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_QCK_SEA_SNGS''
AND a.column_name = ''QSS_DFLTUI_PFR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_QCK_SEA_SNGS.QSS_PAYR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9 * 9) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9 * 9)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_QCK_SEA_SNGS''
AND a.column_name = ''QSS_PAYR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_REVWHEAD.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 * 7892) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 * 7892)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWHEAD''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_REVWHEAD.RWHD_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 * 7892) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 * 7892)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWHEAD''
AND a.column_name = ''RWHD_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_REVWHEAD.RWHD_RFRDOBJ_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 * 7892) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 * 7892)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWHEAD''
AND a.column_name = ''RWHD_RFRDOBJ_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_REVWHEAD.RWHD_RESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7879 * 7879) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7879,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7879 * 7879)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7879 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWHEAD''
AND a.column_name = ''RWHD_RESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_REVWHEAD.RWHD_SNDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 * 7892) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 * 7892)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWHEAD''
AND a.column_name = ''RWHD_SNDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_REVWHEAD.RWHD_RET_TO'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 * 7892) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 * 7892)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7892 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWHEAD''
AND a.column_name = ''RWHD_RET_TO''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_REVWREC.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 * 7900) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 * 7900)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWREC''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_REVWREC.RWRC_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7900) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7900)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWREC''
AND a.column_name = ''RWRC_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_REVWREC.RWRC_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7900) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 7900)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWREC''
AND a.column_name = ''RWRC_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_REVWREC.RWRC_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 * 7900) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 * 7900)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWREC''
AND a.column_name = ''RWRC_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_REVWREC.RWRC_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 * 7900) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 * 7900)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWREC''
AND a.column_name = ''RWRC_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_REVWREC.RWRC_RFRDOBJ_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 * 7900) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 * 7900)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWREC''
AND a.column_name = ''RWRC_RFRDOBJ_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_REVWREC.RWRC_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 * 7900) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 * 7900)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7900 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REVWREC''
AND a.column_name = ''RWRC_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_SENTEMAL.STEL_CNXT_CM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 133 * 133) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 133,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 133 * 133)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 133 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTEMAL''
AND a.column_name = ''STEL_CNXT_CM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTEMAL.STEL_CNXT_MEMB'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 20 * 20) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 20,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 20 * 20)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 20 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTEMAL''
AND a.column_name = ''STEL_CNXT_MEMB''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTEMAL.STEL_CNXT_UM_EVNT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 20 * 20) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 20,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 20 * 20)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 20 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTEMAL''
AND a.column_name = ''STEL_CNXT_UM_EVNT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column T_SENTLTR.SLTT_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 10958 * 10958) rows_per_bucket,
trunc(endpoint_repeat_count / 10958,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 10958 * 10958)||'' Sel: ''||trunc(endpoint_repeat_count / 10958,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTLTR''
AND a.column_name = ''SLTT_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTLTR.SLTT_AFFN_CM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 4993 * 4993) rows_per_bucket,
trunc(endpoint_repeat_count / 4993,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 4993 * 4993)||'' Sel: ''||trunc(endpoint_repeat_count / 4993,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTLTR''
AND a.column_name = ''SLTT_AFFN_CM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTLTR.SLTT_AFFN_MEMB'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 3315 * 3315) rows_per_bucket,
trunc(endpoint_repeat_count / 3315,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 3315 * 3315)||'' Sel: ''||trunc(endpoint_repeat_count / 3315,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTLTR''
AND a.column_name = ''SLTT_AFFN_MEMB''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_SENTTSK.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7365 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7365,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7365 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7365 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7367 * 223306) rows_per_bucket,
trunc(endpoint_repeat_count / 7367,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7367 * 223306)||'' Sel: ''||trunc(endpoint_repeat_count / 7367,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7367 * 223306) rows_per_bucket,
trunc(endpoint_repeat_count / 7367,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7367 * 223306)||'' Sel: ''||trunc(endpoint_repeat_count / 7367,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_VERS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_VERS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_DRTN_UNIT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876 * 2876) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876 * 2876)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_DRTN_UNIT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_RMDRPRCDWTH__UNIT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39 * 39) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39 * 39)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_RMDRPRCDWTH__UNIT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_CMPD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5952 * 180194) rows_per_bucket,
trunc(endpoint_repeat_count / 5952,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5952 * 180194)||'' Sel: ''||trunc(endpoint_repeat_count / 5952,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_CMPD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_TSK_TIMG_DDLN_DT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 2364 * 2364) rows_per_bucket,
trunc(endpoint_repeat_count / 2364,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 2364 * 2364)||'' Sel: ''||trunc(endpoint_repeat_count / 2364,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TIMG_DDLN_DT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_TSK_TIMG_DDLNACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49094 * 49094) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49094,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49094 * 49094)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49094 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TIMG_DDLNACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_TSK_TIMG_STRTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5514 * 54390) rows_per_bucket,
trunc(endpoint_repeat_count / 5514,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5514 * 54390)||'' Sel: ''||trunc(endpoint_repeat_count / 5514,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TIMG_STRTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_AFFN_UM_EVNT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21 * 21) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21 * 21)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_AFFN_UM_EVNT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_ORIGRCPT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7366 * 223306) rows_per_bucket,
trunc(endpoint_repeat_count / 7366,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7366 * 223306)||'' Sel: ''||trunc(endpoint_repeat_count / 7366,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_ORIGRCPT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219029 * 219029) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219029,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219029 * 219029)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219029 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_PRVSOWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 * 64537) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 * 64537)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_PRVSOWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_PRVSSNDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 * 64537) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 * 64537)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_PRVSSNDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_CNCLRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35264 * 35264) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35264,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35264 * 35264)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35264 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_CNCLRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_TSK_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_RESCHEDULE_REASON'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9322 * 9322) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9322,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9322 * 9322)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9322 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_RESCHEDULE_REASON''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.("SETK_OBJ_STT","SETK_AFFN_MEMB")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7365 * 223306) rows_per_bucket,
trunc(endpoint_repeat_count / 7365,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7365 * 223306)||'' Sel: ''||trunc(endpoint_repeat_count / 7365,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_STSU99E0JHXWDB$#3#GYFFGPVG''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.(NVL("SETK_PRNL",0))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_NC00086$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.(NVL("SETK_OWNR","SETK_ORIGRCPT"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7366 * 223306) rows_per_bucket,
trunc(endpoint_repeat_count / 7366,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7366 * 223306)||'' Sel: ''||trunc(endpoint_repeat_count / 7366,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_NC00087$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.(TRUNC("SETK_SENT"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7232 * 219029) rows_per_bucket,
trunc(endpoint_repeat_count / 7232,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7232 * 219029)||'' Sel: ''||trunc(endpoint_repeat_count / 7232,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_NC00088$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_SYTMSTNGDAT.SSDT_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 850 * 850) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 850,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 850 * 850)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 850 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SYTMSTNGDAT''
AND a.column_name = ''SSDT_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SYTMSTNGDAT.SSDT_DFLTDAT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 850 * 850) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 850,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 850 * 850)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 850 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SYTMSTNGDAT''
AND a.column_name = ''SSDT_DFLTDAT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SYTMSTNGDAT.SGSD_STRGVAL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 95 * 95) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 95,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 95 * 95)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 95 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SYTMSTNGDAT''
AND a.column_name = ''SGSD_STRGVAL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SYTMSTNGDAT.BSGD_BOLNVAL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 560 * 560) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 560,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 560 * 560)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 560 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SYTMSTNGDAT''
AND a.column_name = ''BSGD_BOLNVAL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13258 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13258,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13258 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13258 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.TACB_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''TACB_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.TACB_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''TACB_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.TACB_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''TACB_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.TACB_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''TACB_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.STAT_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 55328 * 55328) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 55328,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 55328 * 55328)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 55328 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''STAT_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.TACB_ASMTCC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''TACB_ASMTCC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_TIM_OFF_ITVL.TOIT_APRD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 16 * 16) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 16,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 16 * 16)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 16 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TIM_OFF_ITVL''
AND a.column_name = ''TOIT_APRD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TIM_OFF_ITVL.TOIT_PAYR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 40 * 40) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 40,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 40 * 40)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 40 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TIM_OFF_ITVL''
AND a.column_name = ''TOIT_PAYR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TIM_OFF_ITVL.TOIT_TIM_OFF_REQT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 * 18) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 * 18)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 18 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TIM_OFF_ITVL''
AND a.column_name = ''TOIT_TIM_OFF_REQT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_TIM_OFF_REQT.TOFR_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 * 15) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 * 15)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TIM_OFF_REQT''
AND a.column_name = ''TOFR_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TIM_OFF_REQT.TOFR_PAYRMY_TO_RQS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 * 15) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 * 15)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TIM_OFF_REQT''
AND a.column_name = ''TOFR_PAYRMY_TO_RQS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_TNFRREC.TRRC_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701498 * 1701498) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701498,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701498 * 1701498)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701498 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TNFRREC''
AND a.column_name = ''TRRC_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TNFRREC.TRRC_RFRDOBJ_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701472 * 1701472) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701472,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701472 * 1701472)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701472 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TNFRREC''
AND a.column_name = ''TRRC_RFRDOBJ_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TNFRREC.TRRC_SNDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701472 * 1701472) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701472,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701472 * 1701472)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701472 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TNFRREC''
AND a.column_name = ''TRRC_SNDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TNFRREC.TRRC_RCPT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701468 * 1701468) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701468,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701468 * 1701468)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1701468 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TNFRREC''
AND a.column_name = ''TRRC_RCPT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_TODO.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO.TODO_TYP_SBTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45478 * 45478) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45478,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45478 * 45478)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45478 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_TYP_SBTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_TODO.TODO_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 45496 * 45496) rows_per_bucket,
trunc(endpoint_repeat_count / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 45496 * 45496)||'' Sel: ''||trunc(endpoint_repeat_count / 45496,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_TODO.TODO_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 45496 * 45496) rows_per_bucket,
trunc(endpoint_repeat_count / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 45496 * 45496)||'' Sel: ''||trunc(endpoint_repeat_count / 45496,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO.TODO_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO.TODO_VERS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_VERS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO.TODO_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO.TODO_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO.TODO_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO.TODO_ORIGCRTRLOGDIN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_ORIGCRTRLOGDIN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO.TODO_LAS_ACT_BY_LOGDIN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_LAS_ACT_BY_LOGDIN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_TODO.TODO_TEMPLATE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 45496 * 45496) rows_per_bucket,
trunc(endpoint_repeat_count / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 45496 * 45496)||'' Sel: ''||trunc(endpoint_repeat_count / 45496,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_TEMPLATE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_TODO.TODO_START'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 26320 * 26320) rows_per_bucket,
trunc(endpoint_repeat_count / 26320,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 26320 * 26320)||'' Sel: ''||trunc(endpoint_repeat_count / 26320,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_START''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_TODO.TODO_END'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 17468 * 17468) rows_per_bucket,
trunc(endpoint_repeat_count / 17468,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 17468 * 17468)||'' Sel: ''||trunc(endpoint_repeat_count / 17468,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_END''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO.TODO_STATUS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 * 45496)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 45496 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO''
AND a.column_name = ''TODO_STATUS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_TODO_TEMPLATE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 * 1222) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 * 1222)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO_TEMPLATE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_TODO_TEMPLATE.TODO_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 1222 * 1222) rows_per_bucket,
trunc(endpoint_repeat_count / 1222,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 1222 * 1222)||'' Sel: ''||trunc(endpoint_repeat_count / 1222,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO_TEMPLATE''
AND a.column_name = ''TODO_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO_TEMPLATE.TODO_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 * 1222) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 * 1222)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO_TEMPLATE''
AND a.column_name = ''TODO_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO_TEMPLATE.TODO_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 * 1222) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 * 1222)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO_TEMPLATE''
AND a.column_name = ''TODO_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TODO_TEMPLATE.TODO_TYP_SBTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 * 1222) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 * 1222)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1222 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TODO_TEMPLATE''
AND a.column_name = ''TODO_TYP_SBTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_TSK_BASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 * 221887) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 * 221887)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TSK_BASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TSK_BASE.TKBS_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 * 221887) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 * 221887)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TSK_BASE''
AND a.column_name = ''TKBS_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TSK_BASE.TKBS_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5504 * 221887) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5504,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5504 * 221887)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5504 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TSK_BASE''
AND a.column_name = ''TKBS_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TSK_BASE.TKBS_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 * 221887) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 * 221887)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TSK_BASE''
AND a.column_name = ''TKBS_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TSK_BASE.TKBS_NAM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 220713 * 220713) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 220713,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 220713 * 220713)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 220713 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TSK_BASE''
AND a.column_name = ''TKBS_NAM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_TSK_BASE.TKBS_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5506 * 221887) rows_per_bucket,
trunc(endpoint_repeat_count / 5506,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5506 * 221887)||'' Sel: ''||trunc(endpoint_repeat_count / 5506,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TSK_BASE''
AND a.column_name = ''TKBS_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TSK_BASE.TKBS_TSK_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 * 221887) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 * 221887)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TSK_BASE''
AND a.column_name = ''TKBS_TSK_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TSK_BASE.CTSK_ORIG'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221655 * 221655) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221655,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221655 * 221655)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221655 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TSK_BASE''
AND a.column_name = ''CTSK_ORIG''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TSK_BASE.("CLASSTYPE","TKBS_TSK_TYP")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 * 221887) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 * 221887)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 221887 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TSK_BASE''
AND a.column_name = ''SYS_STSJTNY0UPY8#64LCMCO93U2O0''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TSK_BASE.(UPPER("TKBS_NAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 220713 * 220713) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 220713,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 220713 * 220713)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 220713 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TSK_BASE''
AND a.column_name = ''SYS_NC00079$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_UM_BASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_UM_BASE.UMBS_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_DDLNTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83746 * 83746) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83746,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83746 * 83746)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83746 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_DDLNTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_REQTTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250690 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_REQTTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_DRVDDTMNSTT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250689 * 250689) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250689,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250689 * 250689)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250689 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_DRVDDTMNSTT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMET_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250602 * 250602) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250602,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250602 * 250602)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 250602 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMET_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMER_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 84 * 84) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 84,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 84 * 84)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 84 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMER_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMET_UM_EVNTOTCM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10226 * 10226) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10226,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10226 * 10226)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 10226 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMET_UM_EVNTOTCM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMET_CLSRRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249836 * 249836) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249836,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249836 * 249836)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249836 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMET_CLSRRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_SVTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 27 * 27) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 27,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 27 * 27)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 27 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_SVTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_PITY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 524 * 524) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 524,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 524 * 524)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 524 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_PITY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83480 * 83480) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83480,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83480 * 83480)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83480 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMET_REONRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9112 * 9112) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9112,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9112 * 9112)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9112 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMET_REONRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249340 * 249340) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249340,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249340 * 249340)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 249340 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_RQTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 69961 * 69961) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 69961,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 69961 * 69961)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 69961 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_RQTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_UM_BASE.UMBS_PFNGPVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250663) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250663)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_PFNGPVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_UM_BASE.UMBS_RQNGPVDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 53487) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 53487)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_RQNGPVDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_AUTH_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_AUTH_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_UM_BASE.UMBS_AUTH_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 * 3)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 3 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''UMBS_AUTH_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_UM_BASE.(UPPER("UMBS_C4C_ID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250690) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 250690)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_UM_BASE''
AND a.column_name = ''SYS_NC00123$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_USR.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985458 * 1985458) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985458,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985458 * 1985458)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985458 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_C4C_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1982648) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1982648)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_C4C_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 * 1985613) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 * 1985613)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1985613) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1985613)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 * 1985613) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 * 1985613)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 * 1985613) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 * 1985613)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_UNIVID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1981026) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1981026)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_UNIVID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_FRSTNAM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1875300) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1875300)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_FRSTNAM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_LAS_NAM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983134) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983134)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_LAS_NAM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_DT_OF_BRTH'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1076965) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1076965)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_DT_OF_BRTH''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_GNDRCODE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1096701 * 1096701) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1096701,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1096701 * 1096701)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1096701 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_GNDRCODE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1985613) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1985613)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PRV_IS_ADM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985182 * 1985182) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985182,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985182 * 1985182)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985182 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PRV_IS_ADM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.MBUR_ELBL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 984920 * 984920) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 984920,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 984920 * 984920)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 984920 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''MBUR_ELBL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.MBUR_PMRYINSR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 984933 * 984933) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 984933,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 984933 * 984933)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 984933 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''MBUR_PMRYINSR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.MBUR_INSCID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 984912) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 984912)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''MBUR_INSCID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.MBUR_CNFTCNCT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 979929 * 979929) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 979929,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 979929 * 979929)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 979929 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''MBUR_CNFTCNCT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PAYR_WKLDLMITBY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 781 * 781) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 781,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 781 * 781)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 781 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_WKLDLMITBY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.PAYR_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 784) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 784)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PRV_PVDRTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209880 * 209880) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209880,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209880 * 209880)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209880 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PRV_PVDRTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_ECTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 654286 * 654286) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 654286,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 654286 * 654286)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 654286 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_ECTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_NAM_SFIX'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 87792 * 87792) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 87792,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 87792 * 87792)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 87792 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_NAM_SFIX''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.USR_NAM_PRFX'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 629754 * 629754) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 629754,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 629754 * 629754)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 629754 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_NAM_PRFX''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.MBUR_RLSPTO_SBCR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 983578 * 983578) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 983578,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 983578 * 983578)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 983578 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''MBUR_RLSPTO_SBCR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_MRGEMSTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 419) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 419)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_MRGEMSTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PAYR_BCK1'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155 * 155) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155 * 155)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 155 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_BCK1''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PAYR_SVSR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 379 * 379) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 379,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 379 * 379)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 379 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_SVSR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PAYR_BCK2'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 * 15) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 * 15)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 15 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_BCK2''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PAYR_BCK3'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4 * 4) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4 * 4)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PAYR_BCK3''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.PRV_SPLRTYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209859 * 209859) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209859,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209859 * 209859)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 209859 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''PRV_SPLRTYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_IPGROUPID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 193478) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 193478)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_IPGROUPID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.USR_PRODUCTCATEGORYID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 193246) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 193246)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''USR_PRODUCTCATEGORYID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("PRV_PLN_ID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 209878) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 209878)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00130$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("PRV_UPN_ID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 177175) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 177175)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00131$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("USR_LAS_NAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983134) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1983134)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00132$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("USR_MDLENAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 789902) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 789902)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00138$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("USR_C4C_ID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1982648) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1982648)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00139$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.(CASE "USR_OBJ_STT" WHEN 2 THEN 0 ELSE CASE  WHEN "USR_MRGEMSTR" IS NULL THEN 1 ELSE 0 END  END )'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 * 1985613) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 * 1985613)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1985613 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00140$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.(UPPER("MBUR_MEDICAID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9 * 9) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9 * 9)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00159$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("MBUR_HICNID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 390) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 390)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00161$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("MBUR_INSCID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 984912) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 984912)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00148$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR.(UPPER("PAYR_EMPEID"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34 * 34) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34 * 34)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00150$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("USR_FRSTNAM"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1875300) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1875300)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00151$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_USR.(UPPER("THH_C4C"."REVERSE_STR"("MBUR_INSCID")))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 984912) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 984912)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR''
AND a.column_name = ''SYS_NC00155$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_USR_CNCTINFO.UCTI_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1647665 * 1647665) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1647665,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1647665 * 1647665)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1647665 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_CNCTINFO''
AND a.column_name = ''UCTI_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_USR_CNCTINFO.UCTI_UNIVID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5564 * 1643092) rows_per_bucket,
trunc(endpoint_repeat_count / 5564,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5564 * 1643092)||'' Sel: ''||trunc(endpoint_repeat_count / 5564,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_CNCTINFO''
AND a.column_name = ''UCTI_UNIVID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR_CNCTINFO.UCTI_CNCTMTHD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83 * 83) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83 * 83)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 83 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_CNCTINFO''
AND a.column_name = ''UCTI_CNCTMTHD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR_CNCTINFO.UCTI_PRFSEMAL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 758986 * 758986) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 758986,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 758986 * 758986)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 758986 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_CNCTINFO''
AND a.column_name = ''UCTI_PRFSEMAL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR_CNCTINFO.UCTI_PRFSPHNE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1451248 * 1451248) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1451248,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1451248 * 1451248)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1451248 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_CNCTINFO''
AND a.column_name = ''UCTI_PRFSPHNE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Top-Frequency histogram on Column T_USR_CNCTINFO.UCTI_PRFSMAIL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1645527 * 1645527) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1645527,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1645527 * 1645527)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1645527 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_CNCTINFO''
AND a.column_name = ''UCTI_PRFSMAIL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_USR_LOGN.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5538 * 1982487) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5538,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5538 * 1982487)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5538 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_LOGN''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_USR_LOGN.ULGN_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5540 * 1982486) rows_per_bucket,
trunc(endpoint_repeat_count / 5540,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5540 * 1982486)||'' Sel: ''||trunc(endpoint_repeat_count / 5540,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_LOGN''
AND a.column_name = ''ULGN_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR_LOGN.ULGN_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1982487 * 1982487) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1982487,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1982487 * 1982487)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1982487 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_LOGN''
AND a.column_name = ''ULGN_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_USR_LOGN.ULGN_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1982486 * 1982486) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1982486,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1982486 * 1982486)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1982486 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_LOGN''
AND a.column_name = ''ULGN_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_USR_LOGN.ULGN_UNIVID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5530 * 1980399) rows_per_bucket,
trunc(endpoint_repeat_count / 5530,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5530 * 1980399)||'' Sel: ''||trunc(endpoint_repeat_count / 5530,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_LOGN''
AND a.column_name = ''ULGN_UNIVID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_USR_LOGN.ULGN_USRM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5540 * 1982486) rows_per_bucket,
trunc(endpoint_repeat_count / 5540,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5540 * 1982486)||'' Sel: ''||trunc(endpoint_repeat_count / 5540,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_USR_LOGN''
AND a.column_name = ''ULGN_USRM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_WKFWTSK.WTSK_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_WKFWTSK''
AND a.column_name = ''WTSK_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_WKFWTSK.WTSK_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_WKFWTSK''
AND a.column_name = ''WTSK_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_WKFWTSK.WTSK_WKFWTSK_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_WKFWTSK''
AND a.column_name = ''WTSK_WKFWTSK_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_WKFWTSK.WTSK_RFRDOBJ_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_WKFWTSK''
AND a.column_name = ''WTSK_RFRDOBJ_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_WKFWTSK.("WTSK_WKFWTSK_TYP","WTSK_RFRDOBJ_TYP")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_WKFWTSK''
AND a.column_name = ''SYS_STS44#WQANV0T_SKJCHK7$CTXZ''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_WKFWTSK.("WTSK_OBJ_STT","WTSK_WKFWTSK_TYP","WTSK_RFRDOBJ_TYP")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_WKFWTSK''
AND a.column_name = ''SYS_STSWXAJ7KXA#ZW6BV#EJG$V82B''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_WKFWTSK.("WTSK_OBJ_STT","WTSK_RFRDOBJ_TYP")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 * 2299842)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2299842 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_WKFWTSK''
AND a.column_name = ''SYS_STSPU#KS7#8_N#_L806ZZX3SY1''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00961_sqld360_323688_3hwq5m5h3gkaq_3a_68_histograms.html APP;
PRO </td>

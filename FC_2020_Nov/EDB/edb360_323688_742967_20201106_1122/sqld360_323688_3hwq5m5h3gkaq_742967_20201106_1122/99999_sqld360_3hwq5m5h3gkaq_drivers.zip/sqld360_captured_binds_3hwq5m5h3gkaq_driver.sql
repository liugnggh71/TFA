SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B1 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B1'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B1 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B1'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B1 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B1'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B1'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B1 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B1'
AND datatype_string = 'VARCHAR2(2000)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B1'
AND datatype_string = 'VARCHAR2(2000)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B10 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B10'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B10 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B10'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B10 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B10'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B10'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B100 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B100'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B100 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B100'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B100 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B100'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B100'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B101 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B101'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B101 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B101'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B101 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B101'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B101'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B102 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B102'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B102 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B102'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B102 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B102'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B102'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B103 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B103'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B103 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B103'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B103 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B103'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B103'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B104 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B104'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B104 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B104'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B104 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B104'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B104'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B105 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B105'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B105 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B105'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B105 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B105'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B105'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B106 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B106'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B106 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B106'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B106 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B106'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B106'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B107 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B107'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B107 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B107'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B107 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B107'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B107'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B108 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B108'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B108 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B108'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B108 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B108'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B108'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B109 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B109'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B109 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B109'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B109 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B109'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B109'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B11 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B11'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B11 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B11'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B11 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B11'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B11'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B110 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B110'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B110 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B110'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B110 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B110'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B110'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B111 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B111'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B111 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B111'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B111 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B111'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B111'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B112 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B112'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B112 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B112'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B112 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B112'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B112'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B113 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B113'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B113 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B113'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B113 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B113'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B113'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B114 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B114'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B114 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B114'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B114 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B114'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B114'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B115 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B115'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B115 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B115'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B115 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B115'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B115'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B116 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B116'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B116 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B116'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B116 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B116'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B116'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B117 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B117'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B117 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B117'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B117 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B117'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B117'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B118 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B118'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B118 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B118'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B118 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B118'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B118'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B119 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B119'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B119 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B119'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B119 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B119'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B119'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B12 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B12'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B12 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B12'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B12 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B12'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B12'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B120 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B120'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B120 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B120'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B120 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B120'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B120'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B121 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B121'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B121 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B121'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B121 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B121'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B121'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B122 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B122'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B122 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B122'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B122 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B122'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B122'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B123 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B123'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B123 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B123'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B123 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B123'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B123'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B124 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B124'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B124 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B124'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B124 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B124'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B124'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B125 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B125'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B125'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B126 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B126'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B126'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B127 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B127'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B127 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B127'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B127 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B127'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B127'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B128 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B128'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B128 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B128'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B128 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B128'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B128'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B129 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B129'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B129 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B129'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B129 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B129'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B129'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B13 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B13'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B13 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B13'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B13 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B13'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B13'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B130 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B130'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B130'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B131 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B131'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B131 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B131'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B131 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B131'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B131'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B132 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B132'
AND datatype_string = 'VARCHAR2(2000)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B132'
AND datatype_string = 'VARCHAR2(2000)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B133 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B133'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B133 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B133'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B133 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B133'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B133'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B134 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B134'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B134 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B134'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B134 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B134'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B134'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B14 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B14'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B14 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B14'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B14 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B14'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B14'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B15 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B15'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B15'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B16 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B16'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B16'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B17 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B17'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B17'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B18 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B18'
AND datatype_string = 'VARCHAR2(128)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B18'
AND datatype_string = 'VARCHAR2(128)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B18 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B18'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B18'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B19 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B19'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B19 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B19'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B19 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B19'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B19'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B2 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B2'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B2'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B20 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B20'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B20 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B20'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B20 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B20'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B20'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B21 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B21'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B21 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B21'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B21 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B21'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B21'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B22 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B22'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B22 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B22'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B22 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B22'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B22'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B23 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B23'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B23 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B23'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B23 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B23'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B23'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B24 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B24'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B24'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B25 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B25'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B25'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B26 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B26'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B26 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B26'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B26 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B26'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B26'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B27 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B27'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B27 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B27'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B27 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B27'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B27'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B28 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B28'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B28 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B28'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B28 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B28'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B28'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B29 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B29'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B29 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B29'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B29 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B29'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B29'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B3 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B3'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B3 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B3'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B3 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B3'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B3'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B30 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B30'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B30'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B31 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B31'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B31'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B32 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B32'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B32'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B33 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B33'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B33 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B33'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B33 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B33'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B33'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B34 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B34'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B34 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B34'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B34 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B34'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B34'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B35 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B35'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B35 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B35'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B35 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B35'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B35'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B36 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B36'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B36 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B36'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B36 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B36'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B36'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B37 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B37'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B37 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B37'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B37 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B37'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B37'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B38 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B38'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B38 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B38'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B38 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B38'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B38'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B39 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B39'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B39'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B4 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B4'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B4 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B4'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B4 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B4'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B4'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B40 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B40'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B40 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B40'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B40 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B40'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B40'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B41 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B41'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B41 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B41'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B41 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B41'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B41'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B42 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B42'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B42 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B42'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B42 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B42'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B42'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B43 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B43'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B43 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B43'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B43 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B43'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B43'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B44 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B44'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B44 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B44'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B44 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B44'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B44'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B45 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B45'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B45 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B45'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B45 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B45'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B45'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B46 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B46'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B46'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B47 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B47'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B47'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B48 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B48'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B48 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B48'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B48 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B48'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B48'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B49 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B49'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B49 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B49'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B49 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B49'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B49'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B5 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B5'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B5 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B5'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B5 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B5'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B5'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B50 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B50'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B50'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B51 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B51'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B51'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B52 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B52'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B52 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B52'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B52 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B52'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B52'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B53 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B53'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B53'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B54 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B54'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B54 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B54'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B54 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B54'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B54'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B55 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B55'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B55 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B55'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B55 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B55'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B55'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B56 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B56'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B56'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B57 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B57'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B57'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Top 15 bind :B58 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B58'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B58'
AND datatype_string = 'VARCHAR2(32)'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B59 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B59'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B59 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B59'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B59 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B59'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B59'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B6 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B6'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B6 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B6'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B6 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B6'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B6'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B60 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B60'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B60 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B60'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B60 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B60'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B60'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B61 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B61'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B61 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B61'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B61 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B61'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B61'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B62 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B62'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B62 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B62'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B62 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B62'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B62'
AND datatype_string = 'DATE'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B63 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B63'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B63 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B63'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B63 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B63'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B63'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B64 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B64'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B64 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B64'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B64 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B64'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B64'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B65 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B65'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B65 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B65'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B65 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B65'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B65'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B66 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B66'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B66 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B66'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B66 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B66'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B66'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B67 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B67'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B67 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B67'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B67 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B67'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B67'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B68 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B68'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B68 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B68'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B68 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B68'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B68'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B69 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B69'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B69 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B69'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B69 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B69'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B69'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B7 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B7'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B7 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B7'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B7 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B7'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B7'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B70 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B70'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B70 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B70'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B70 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B70'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B70'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B71 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B71'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B71 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B71'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B71 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B71'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B71'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B72 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B72'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B72 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B72'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B72 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B72'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B72'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B73 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B73'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B73 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B73'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B73 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B73'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B73'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B74 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B74'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B74 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B74'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B74 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B74'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B74'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B75 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B75'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B75 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B75'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B75 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B75'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B75'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B76 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B76'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B76 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B76'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B76 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B76'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B76'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B77 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B77'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B77 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B77'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B77 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B77'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B77'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B78 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B78'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B78 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B78'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B78 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B78'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B78'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B79 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B79'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B79 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B79'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B79 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B79'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B79'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B8 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B8'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B8 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B8'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B8 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B8'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B8'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B80 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B80'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B80 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B80'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B80 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B80'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B80'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B81 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B81'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B81 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B81'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B81 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B81'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B81'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B82 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B82'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B82 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B82'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B82 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B82'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B82'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B83 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B83'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B83 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B83'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B83 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B83'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B83'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B84 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B84'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B84 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B84'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B84 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B84'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B84'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B85 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B85'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B85 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B85'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B85 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B85'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B85'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B86 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B86'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B86 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B86'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B86 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B86'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B86'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B87 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B87'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B87 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B87'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B87 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B87'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B87'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B88 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B88'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B88 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B88'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B88 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B88'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B88'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B89 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B89'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B89 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B89'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B89 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B89'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B89'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B9 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B9'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B9 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B9'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B9 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B9'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B9'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B90 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B90'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B90 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B90'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B90 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B90'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B90'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B91 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B91'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B91 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B91'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B91 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B91'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B91'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B92 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B92'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B92 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B92'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B92 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B92'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B92'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B93 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B93'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B93 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B93'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B93 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B93'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B93'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B94 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B94'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B94 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B94'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B94 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B94'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B94'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B95 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B95'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B95 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B95'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B95 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B95'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B95'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B96 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B96'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B96 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B96'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B96 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B96'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B96'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B97 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B97'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B97 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B97'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B97 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B97'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B97'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B98 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B98'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B98 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B98'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B98 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B98'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B98'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>
SET PAGES 50000
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO <td>
SPO OFF
DEF title= 'Bind :B99 values over time from memory'
DEF vAxis = 'Bind Value'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM gv$sql_bind_capture
WHERE name = ':B99'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title = 'Bind :B99 values over time from history'
DEF vAxis = 'Bind Value'
DEF main_table = 'DBA_HIST_SQLBIND'
DEF skip_sch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT /*+ NO_MERGE */ DISTINCT
TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS') last_captured,
value_string,
datatype_string,
'Captured: '||TO_CHAR(last_captured, 'YYYY-MM-DD HH24:MI:SS')||', Value: '||value_string tooltip
FROM dba_hist_sqlbind
WHERE name = ':B99'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND snap_id BETWEEN 3484 AND 4973
AND last_captured IS NOT NULL
AND 'Y' = 'Y'
ORDER BY last_captured
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
DEF title= 'Top 15 bind :B99 values used'
DEF main_table = 'GV$SQL_BIND_CAPTURE'
DEF skip_bch=''
COL tooltip NOPRI
BEGIN
:sql_text := q'[
SELECT value_string,
num_captures,
null,
'Value: '||value_string||' - Number of times captured: '||num_captures||' ('||TRUNC(100*RATIO_TO_REPORT(num_captures) OVER (),2)||'% of total)' tooltip
FROM (SELECT value_string,
COUNT(*) num_captures
FROM (SELECT value_string
FROM gv$sql_bind_capture
WHERE name = ':B99'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
UNION
SELECT value_string
FROM dba_hist_sqlbind
WHERE name = ':B99'
AND datatype_string = 'NUMBER'
AND sql_id = '3hwq5m5h3gkaq'
AND last_captured IS NOT NULL
AND snap_id BETWEEN 3484 AND 4973
AND 'Y' = 'Y')
GROUP BY value_string
ORDER BY 2 DESC)
WHERE rownum <= 15
]';
END;
/
@sql/sqld360_9a_pre_one.sql
COL tooltip PRI
SPO 00267_sqld360_323688_3hwq5m5h3gkaq_2g_54_captured_binds_details.html APP;
PRO </td>

EXEC DBMS_UTILITY.EXPAND_SQL_TEXT(:sqld360_fullsql,:myexpandedsql);

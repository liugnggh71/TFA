BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 95570
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_16777216_09212020005405_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 100757
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_33554432_09232020005523_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 72430
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_16777220_09082020001316_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 98094
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_16777217_09222020010058_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 83075
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_16777218_09142020002658_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 57809
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_16777216_08312020002406_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 86553
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_33554432_09162020003012_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 89956
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_33554434_09182020002506_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 59579
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_33554432_09012020002734_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 79940
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_16777217_09122020002733_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 84789
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_33554433_09152020003004_hist.html;
PRINT :myreport;
SPO OFF;
BEGIN
:myreport :=
DBMS_AUTO_REPORT.REPORT_REPOSITORY_DETAIL
( rid => 78180
, type => 'ACTIVE' );
END;
/
SPO sqld360_sqlmon_d1bmu84pdu6gx_16777216_09112020002827_hist.html;
PRINT :myreport;
SPO OFF;

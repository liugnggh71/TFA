SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('SYS_AUTO_SQL_TUNING_TASK','EXEC_99267') FROM dual;
------------------------------------------------------------------------
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('TASK_95529','EXEC_98765') FROM dual;
------------------------------------------------------------------------

BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_FRM_CELLTXT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_MEMBDGISBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_QTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_REP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_RSPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_RSPECHCS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SENTCAREBEAN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_STTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'TABLE'
, name => 'T_TAKNASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CBDG_MDCLCLM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CCTR_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_AMTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_CM_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_SENTASMT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CFDS_THE_BRNCACT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_CMDI_CMBASE_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FMCT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FMCT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FMCT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FMCT_RSPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_FMCT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_DGISUMEVNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MBDB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_MEMB_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_SRC__ASMTCARECALC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_SRC__PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_TAKNASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_MDSS_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_OBJ_STT_AFFN_MEMB_SETK_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_ALM_FRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_ASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_C4C_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_C4C_ID_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_C4C_ID_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_CAREBEANFRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_DGESFRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_ORIG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_QTN_FRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_QTN_TXT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_QTN_TXT_DS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_QTN_TXT_RS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_REP_FRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_SCLB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_SKIPFRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_STTSFMLS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_TSK_FRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_TYP_SBTY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_VSBT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_QTN_WGHTFRMA'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RESP_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RESP_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RESP_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RESP_TAKNASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RESP_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPCH_CHCS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPCH_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPCH_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPCH_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPCH_RSPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPCH_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPT_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPT_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPT_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPT_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPT_TAKNASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPT_THE_BRNCACT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_RPT_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SCBT_CAREBEANTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SCBT_CB_SETK_TMTD_AFFM_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SCBT_CB_STK_TD_AFM_NVL_PRNL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CNCLRESN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_ORIGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_OWNRORIGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_REPP_STARTDATEALL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_RETNPTRN_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_SENT_Y2D'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_SRC__ASMTCARECALC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_SRC__PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_STARTDATEALL'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_STRTSNLTDT_LOWB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TAKNASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TMPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TMTD_HIGHB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TMTD_HIGHBX'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_TSK_TYP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_UM_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SETK_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_SKC4CID_SKID_SKTSKNM_CT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_RTKNORIG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_SENTLTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STAT_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STA_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STA_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STA_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STA_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STA_TAKNASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STA_THE_BRNCACT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STA_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_CM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_PVDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_UM_EVNT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_UM_EVNTREQT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_AFFN_UM_EXTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_CAREBEAN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_CAUDBY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_CSTMFLDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_GRP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_LAS_GKPR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_ORIGRCPT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_OWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSOWNR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSOWNRPRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSRFNGTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSRFNGTSK_PRMN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSSNDR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_PRVSTNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_RFNGWKFWTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_SENT_Y2D'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_SRC__ASMTCARECALC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_SRC__PAT_ID_QRY'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_TAKNASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_TAKNASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_TNFR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_STCB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_ASMTCC'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_CLASSTYPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_CLLDSTTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_CRTD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_CURRQTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_MEMB'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_OBJ_STT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_TACB_UNIVID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMAD_UMBS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMDS_DGISUMEVNT_DGIS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'IX_UMDS_SNP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PERFTMEMBDGISX5'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_FRM_CELLTXT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_MEMBDGISBASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_QTN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_REP'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_RSPE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_RSPECHCS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SENTCAREBEAN'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_SENTTSK'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_STTS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'PK_T_TAKNASMTCC_BASE'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'SYS_IL0000115282C00051$$'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_CFPRBLMDS_THE_BRNCACT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTSK_UX_EVNTREQT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_CM_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_EVNT_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_EXTN_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_MEMB_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'T_SENTTSK_UX_ORIG_ID'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CBDG'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CCTR'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CFDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CFPRBLMDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_CMDI'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_MDSS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_RSPE_QTN_SENTASSM'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_SCBT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_STAT'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMAD'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;
BEGIN
:mymetadata :=
DBMS_METADATA.GET_DDL
( object_type => 'INDEX'
, name => 'UK_UMDS'
, schema => 'THH_C4C');
END;
/
PRINT :mymetadata;

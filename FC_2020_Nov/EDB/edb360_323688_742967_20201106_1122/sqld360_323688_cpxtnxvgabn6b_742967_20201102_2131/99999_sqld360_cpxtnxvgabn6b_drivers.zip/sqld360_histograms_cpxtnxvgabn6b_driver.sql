SET PAGES 50000
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MBDB_C4C_ID'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 380497) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 380497)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_C4C_ID''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MBDB_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MBDB_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MBDB_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MBDB_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MBDB_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 397418 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MDSS_STRTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 384675) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 384675)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_STRTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MDSS_END_DT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 18737) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 18737)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_END_DT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MDSS_IS_PMRYDGIS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 198641 * 198641) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 198641,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 198641 * 198641)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 198641 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_IS_PMRYDGIS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MDSS_IS_ERR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185207 * 185207) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185207,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185207 * 185207)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 185207 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_IS_ERR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MDSS_SRC__ASMTCARECALC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1029 * 1029) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1029,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1029 * 1029)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 1029 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_SRC__ASMTCARECALC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MBDB_DGIS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 396970) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 396970)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MBDB_DGIS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.MDSS_CAUDBY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1025) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 1025)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MDSS_CAUDBY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.UMAD_UMBS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 276 * 276) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 276,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 276 * 276)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 276 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''UMAD_UMBS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MPDS_PRBLM_STATUS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17818 * 17818) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17818,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17818 * 17818)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 17818 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MPDS_PRBLM_STATUS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_MEMBDGISBASE.MPDS_PRBLM_SRC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9726 * 9726) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9726,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9726 * 9726)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9726 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''MPDS_PRBLM_SRC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Height Balanced histogram on Column T_MEMBDGISBASE.("CLASSTYPE","MBDB_DGIS","MDSS_MEMB")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 * 397418)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 254 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_MEMBDGISBASE''
AND a.column_name = ''SYS_STS16QW#IPBEJF$IE2_54ZF$HM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_QTN.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593 * 7593) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593 * 7593)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_QTN''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_QTN.QTN_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593 * 7593) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593 * 7593)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_QTN''
AND a.column_name = ''QTN_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_QTN.QTN_RSPETYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593 * 7593) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593 * 7593)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7593 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_QTN''
AND a.column_name = ''QTN_RSPETYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_QTN.QTN_IN_POOL'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4710 * 4710) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4710,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4710 * 4710)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 4710 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_QTN''
AND a.column_name = ''QTN_IN_POOL''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_QTN.QTN_OTXTLMIT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7562 * 7562) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7562,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7562 * 7562)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7562 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_QTN''
AND a.column_name = ''QTN_OTXTLMIT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_QTN.QTN_TYP_SBTY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 632 * 632) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 632,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 632 * 632)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 632 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_QTN''
AND a.column_name = ''QTN_TYP_SBTY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_QTN.QTN_ORIG'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 533 * 533) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 533,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 533 * 533)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 533 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_QTN''
AND a.column_name = ''QTN_ORIG''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_QTN.QTN_ASMTCC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7480 * 7480) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7480,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7480 * 7480)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7480 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_QTN''
AND a.column_name = ''QTN_ASMTCC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_REP.RPT_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34 * 34) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34 * 34)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 34 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_REP''
AND a.column_name = ''RPT_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column T_RSPE.RESP_QTN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5597 * 804073) rows_per_bucket,
trunc(endpoint_repeat_count / 5597,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5597 * 804073)||'' Sel: ''||trunc(endpoint_repeat_count / 5597,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_RSPE''
AND a.column_name = ''RESP_QTN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Hybrid histogram on Column T_RSPECHCS.RPCH_CHCS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5803 * 517497) rows_per_bucket,
trunc(endpoint_repeat_count / 5803,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5803 * 517497)||'' Sel: ''||trunc(endpoint_repeat_count / 5803,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_RSPECHCS''
AND a.column_name = ''RPCH_CHCS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_SENTTSK.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7365 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7365,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7365 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 7365 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_CRTD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7367 * 223306) rows_per_bucket,
trunc(endpoint_repeat_count / 7367,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7367 * 223306)||'' Sel: ''||trunc(endpoint_repeat_count / 7367,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_CRTD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_LAS_ACT_TIM'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7367 * 223306) rows_per_bucket,
trunc(endpoint_repeat_count / 7367,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7367 * 223306)||'' Sel: ''||trunc(endpoint_repeat_count / 7367,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_LAS_ACT_TIM''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_VERS'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_VERS''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_DRTN_UNIT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876 * 2876) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876 * 2876)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 2876 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_DRTN_UNIT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_RMDRPRCDWTH__UNIT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39 * 39) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39 * 39)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 39 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_RMDRPRCDWTH__UNIT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_CMPD'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5952 * 180194) rows_per_bucket,
trunc(endpoint_repeat_count / 5952,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5952 * 180194)||'' Sel: ''||trunc(endpoint_repeat_count / 5952,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_CMPD''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_TSK_TIMG_DDLN_DT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 2364 * 2364) rows_per_bucket,
trunc(endpoint_repeat_count / 2364,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 2364 * 2364)||'' Sel: ''||trunc(endpoint_repeat_count / 2364,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TIMG_DDLN_DT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_TSK_TIMG_DDLNACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49094 * 49094) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49094,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49094 * 49094)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 49094 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TIMG_DDLNACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_TSK_TIMG_STRTDT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 5514 * 54390) rows_per_bucket,
trunc(endpoint_repeat_count / 5514,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 5514 * 54390)||'' Sel: ''||trunc(endpoint_repeat_count / 5514,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TIMG_STRTDT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_AFFN_UM_EVNT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21 * 21) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21 * 21)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 21 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_AFFN_UM_EVNT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.SETK_ORIGRCPT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7366 * 223306) rows_per_bucket,
trunc(endpoint_repeat_count / 7366,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7366 * 223306)||'' Sel: ''||trunc(endpoint_repeat_count / 7366,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_ORIGRCPT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219029 * 219029) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219029,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219029 * 219029)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 219029 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_PRVSOWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 * 64537) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 * 64537)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_PRVSOWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_PRVSSNDR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 * 64537) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 * 64537)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64537 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_PRVSSNDR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_CNCLRESN'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35264 * 35264) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35264,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35264 * 35264)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 35264 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_CNCLRESN''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_TSK_TYP'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_TSK_TYP''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.SETK_RESCHEDULE_REASON'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9322 * 9322) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9322,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9322 * 9322)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 9322 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SETK_RESCHEDULE_REASON''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.("SETK_OBJ_STT","SETK_AFFN_MEMB")'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7365 * 223306) rows_per_bucket,
trunc(endpoint_repeat_count / 7365,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7365 * 223306)||'' Sel: ''||trunc(endpoint_repeat_count / 7365,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_STSU99E0JHXWDB$#3#GYFFGPVG''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_SENTTSK.(NVL("SETK_PRNL",0))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 * 223306)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 223306 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_NC00086$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.(NVL("SETK_OWNR","SETK_ORIGRCPT"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7366 * 223306) rows_per_bucket,
trunc(endpoint_repeat_count / 7366,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7366 * 223306)||'' Sel: ''||trunc(endpoint_repeat_count / 7366,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_NC00087$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Hybrid histogram on Column T_SENTTSK.(TRUNC("SETK_SENT"))'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round(endpoint_repeat_count / 7232 * 219029) rows_per_bucket,
trunc(endpoint_repeat_count / 7232,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''DATE'' = ''DATE'' or ''DATE'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''DATE'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round(endpoint_repeat_count / 7232 * 219029)||'' Sel: ''||trunc(endpoint_repeat_count / 7232,6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_SENTTSK''
AND a.column_name = ''SYS_NC00088$''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_STTS.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5493 * 26820) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5493,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5493 * 26820)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5493 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_STTS''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_STTS.STA_VSBT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5493 * 26820) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5493,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5493 * 26820)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 5493 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_STTS''
AND a.column_name = ''STA_VSBT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO </td>
SET PAGES 50000
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO <td>
SPO OFF
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.CLASSTYPE'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13258 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13258,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''VARCHAR2'' = ''DATE'' or ''VARCHAR2'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''VARCHAR2'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13258 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 13258 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''CLASSTYPE''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.TACB_LAS_ACT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''TACB_LAS_ACT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.TACB_OBJ_STT'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''TACB_OBJ_STT''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.TACB_LAS_ACT_BY'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''TACB_LAS_ACT_BY''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.TACB_ORIGCRTR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''TACB_ORIGCRTR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.STAT_OWNR'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 55328 * 55328) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 55328,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 55328 * 55328)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 55328 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''STAT_OWNR''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
DEF title= 'Frequency histogram on Column T_TAKNASMTCC_BASE.TACB_ASMTCC'
DEF main_table = 'DBA_TAB_HISTOGRAMS'
BEGIN
:sql_text := '
SELECT /*+ NO_MERGE */
CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END approximate_value,
round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151) rows_per_bucket,
trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151,6) selectivity,
''ApproxValue: ''||CASE WHEN endpoint_actual_value IS NOT NULL THEN REPLACE(endpoint_actual_value, '''''''', '''')
WHEN endpoint_actual_value IS NULL THEN
CASE WHEN ''NUMBER'' = ''DATE'' or ''NUMBER'' LIKE ''TIMESTAMP%'' THEN
TO_CHAR(TO_DATE(TO_CHAR(TRUNC(endpoint_value)), ''J'') + (endpoint_value - TRUNC(endpoint_value)),''SYYYY/MM/DD HH24:MI:SS'')
WHEN ''NUMBER'' IN (''NUMBER'', ''FLOAT'', ''BINARY_FLOAT'') THEN
TO_CHAR(endpoint_value)
ELSE
UTL_RAW.CAST_TO_VARCHAR2(SUBSTR(LPAD(TO_CHAR(endpoint_value,''fmxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx''),30,''0''),1,12))
END
END||'' NumRows: ''||round((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 * 64151)||'' Sel: ''||trunc((a.endpoint_number - lag(a.endpoint_number,1,0) over (order by a.endpoint_number)) / 64151 , 6) chart_text
FROM dba_tab_histograms a
WHERE a.owner = ''THH_C4C''
AND a.table_name = ''T_TAKNASMTCC_BASE''
AND a.column_name = ''TACB_ASMTCC''
ORDER BY a.endpoint_number
';
END;
/
DEF skip_bch=''
@sql/sqld360_9a_pre_one.sql
SPO 00208_sqld360_323688_cpxtnxvgabn6b_3a_68_histograms.html APP;
PRO </td>

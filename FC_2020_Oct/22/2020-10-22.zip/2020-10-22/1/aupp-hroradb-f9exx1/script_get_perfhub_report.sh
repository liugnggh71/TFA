 				
				pid=$$
	
				if [ false == "false" ]
				then
					START=`/bin/echo oct/22/2020 10:58:00|/bin/sed "s/jan/01/"|/bin/sed "s/feb/02/"|/bin/sed "s/mar/03/"|/bin/sed "s/apr/04/"|/bin/sed "s/may/05/"|/bin/sed "s/jun/06/"|/bin/sed "s/jul/07/"|/bin/sed "s/aug/08/"|/bin/sed "s/sep/09/"|/bin/sed "s/oct/10/"|/bin/sed "s/nov/11/"| /bin/sed "s/dec/12/"|/bin/sed 's/\//ZZeZZ/g'`
					END=`/bin/echo oct/22/2020 12:33:00|/bin/sed "s/jan/01/"|/bin/sed "s/feb/02/"|/bin/sed "s/mar/03/"|/bin/sed "s/apr/04/"|/bin/sed "s/may/05/"|/bin/sed "s/jun/06/"|/bin/sed "s/jul/07/"|/bin/sed "s/aug/08/"|/bin/sed "s/sep/09/"|/bin/sed "s/oct/10/"|/bin/sed "s/nov/11/"| /bin/sed "s/dec/12/"|/bin/sed 's/\//ZZeZZ/g'`
				else
				 	gap=`/bin/echo %AWR_DURATION% |/bin/sed "s/h//"|/bin/awk '{print ($0-int($0)>0)?int($0)+1:int($0)}'`
                                	START=`/bin/date --date "$dte -$gap hours" +"%m/%d/%Y %H:%M:%S"|/bin/sed 's/\//ZZeZZ/g'`
                                	END=`/bin/date +"%m/%d/%Y %H:%M:%S"|/bin/sed 's/\//ZZeZZ/g'`
				fi
				/opt/oracle.ahf/tfa/resources/scripts/srdc_sql_accept_to_define.pl <$ORACLE_HOME/rdbms/admin/perfhubrpt.sql |/bin/sed "s/DEFINE selected_start_time=\"\&start_time\"/DEFINE selected_start_time=\"$START\"/" |/bin/sed "s/DEFINE selected_end_time=\"\&end_time\"/DEFINE selected_end_time=\"$END\"/" > /u01/oracle.ahf/data/repository/suptools/srdc/user_oracle/1604291124_srdc_dbperf/srdc_perfhubrpt_$pid.sql
				/bin/sed 's/ZZeZZ/\//g' /u01/oracle.ahf/data/repository/suptools/srdc/user_oracle/1604291124_srdc_dbperf/srdc_perfhubrpt_$pid.sql > /u01/oracle.ahf/data/repository/suptools/srdc/user_oracle/1604291124_srdc_dbperf/srdc_perfhubrpt_timed_$pid.sql
				/bin/echo "exit;" >> /u01/oracle.ahf/data/repository/suptools/srdc/user_oracle/1604291124_srdc_dbperf/srdc_perfhubrpt_timed_$pid.sql
				$ORACLE_HOME/bin/sqlplus -s / as sysdba @/u01/oracle.ahf/data/repository/suptools/srdc/user_oracle/1604291124_srdc_dbperf/srdc_perfhubrpt_timed_$pid.sql
				/bin/rm -f /u01/oracle.ahf/data/repository/suptools/srdc/user_oracle/1604291124_srdc_dbperf/srdc_perfhubrpt_$pid.sql
				/bin/rm -f /u01/oracle.ahf/data/repository/suptools/srdc/user_oracle/1604291124_srdc_dbperf/srdc_perfhubrpt_timed_$pid.sql
			
